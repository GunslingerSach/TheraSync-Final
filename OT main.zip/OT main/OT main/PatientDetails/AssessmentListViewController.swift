import UIKit

class AssessmentListViewController: UIViewController {

    // MARK: - Data
    // Stores the selected strings (e.g., "Birth History", "ADOS")
    var selectedAssessments = Set<String>()

    // MARK: - UI Components
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        return scrollView
    }()

    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private let mainStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 24
        return stackView
    }()

    private let beginButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Begin Assessment", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 25
        button.layer.masksToBounds = true
        return button
    }()

    // MARK: - View Lifecycle
    override func loadView() {
        // Assuming you have GradientView class defined elsewhere
        let gradientView = GradientView()
        self.view = gradientView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
        setupViews()
        setupLayout()
        addSections()
        
        // Connect Button Action
        beginButton.addTarget(self, action: #selector(didTapBeginButton), for: .touchUpInside)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    // MARK: - Actions

    @objc private func addButtonTapped() {
        print("Add button tapped")
    }
    
    @objc private func checkboxTapped(_ sender: UIButton) {
        sender.isSelected.toggle()
        
        // We look at the parent view (the 'item' view) to find the label associated with this checkbox
        if let parentView = sender.superview,
           let label = parentView.subviews.compactMap({ $0 as? UILabel }).first,
           let text = label.text {
            
            if sender.isSelected {
                selectedAssessments.insert(text)
                print("Added: \(text)")
            } else {
                selectedAssessments.remove(text)
                print("Removed: \(text)")
            }
        }
    }
    
    @objc private func didTapBeginButton() {
        // 1. Validation
        if selectedAssessments.isEmpty {
            let alert = UIAlertController(title: "No Selection", message: "Please select at least one assessment to begin.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            return
        }
        
        // 2. Create Destination VC
        let nextVC = AssessmentList()
        
        // 3. Pass Data (Convert Set to Array)
        nextVC.assessmentsToDisplay = Array(selectedAssessments).sorted()
        
        // 4. Navigate
        navigationController?.pushViewController(nextVC, animated: true)
    }

    // MARK: - Layout & Setup (Standard)

    private func setupNavigationBar() {
        title = "Assessment List"
        // Configure transparent nav bar with white text
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
    }

    private func setupViews() {
        view.addSubview(beginButton)
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        contentView.addSubview(mainStackView)
    }

    private func setupLayout() {
        let safeArea = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            // Scroll View
            scrollView.topAnchor.constraint(equalTo: safeArea.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: beginButton.topAnchor, constant: -10),

            // Content View
            contentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            
            // Stack View
            mainStackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            mainStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            mainStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            mainStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),

            // Button
            beginButton.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 16),
            beginButton.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: -16),
            beginButton.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: -10),
            beginButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func addSections() {
        let sections = [
            (title: "History", items: ["Birth History", "Medical History"]),
            (title: "Complaints", items: ["Patient Difficulties", "School Complaints"]),
            (title: "Skills", items: ["Gross Motor Skills", "Fine Motor Skills", "Cognitive Skills", "ADOS"])
        ]
        
        for section in sections {
            let sectionView = createSectionView(title: section.title, itemTitles: section.items)
            mainStackView.addArrangedSubview(sectionView)
        }
    }

    // MARK: - View Helpers

    private func createSectionView(title: String, itemTitles: [String]) -> UIView {
        let sectionStackView = UIStackView()
        sectionStackView.axis = .vertical
        sectionStackView.spacing = 8
        sectionStackView.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = .systemFont(ofSize: 16, weight: .medium)
        titleLabel.textColor = .darkGray // Visible against white/gray
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        // Container for padding
        let titleContainer = UIView()
        titleContainer.addSubview(titleLabel)
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: titleContainer.topAnchor),
            titleLabel.bottomAnchor.constraint(equalTo: titleContainer.bottomAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: titleContainer.leadingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: titleContainer.trailingAnchor)
        ])
        
        sectionStackView.addArrangedSubview(titleContainer)
        
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 16
        cardView.layer.masksToBounds = true
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let itemsStackView = UIStackView()
        itemsStackView.axis = .vertical
        itemsStackView.spacing = 0
        itemsStackView.translatesAutoresizingMaskIntoConstraints = false
        
        for (index, itemTitle) in itemTitles.enumerated() {
            let item = createListItemView(title: itemTitle)
            itemsStackView.addArrangedSubview(item)
            
            if index < itemTitles.count - 1 {
                let separator = createSeparatorView()
                itemsStackView.addArrangedSubview(separator)
            }
        }
        
        cardView.addSubview(itemsStackView)
        sectionStackView.addArrangedSubview(cardView)
        
        NSLayoutConstraint.activate([
            itemsStackView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 8),
            itemsStackView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -8),
            itemsStackView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            itemsStackView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -16)
        ])

        return sectionStackView
    }

    private func createListItemView(title: String) -> UIView {
        let itemView = UIView()
        itemView.translatesAutoresizingMaskIntoConstraints = false
        
        let checkbox = UIButton()
        checkbox.translatesAutoresizingMaskIntoConstraints = false
        let deselectedImage = UIImage(systemName: "circle")
        let selectedImage = UIImage(systemName: "checkmark.circle.fill")
        checkbox.setImage(deselectedImage, for: .normal)
        checkbox.setImage(selectedImage, for: .selected)
        checkbox.tintColor = .systemBlue
        checkbox.addTarget(self, action: #selector(checkboxTapped(_:)), for: .touchUpInside)
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = title
        label.font = .systemFont(ofSize: 17)
        label.textColor = .black
        
        itemView.addSubview(checkbox)
        itemView.addSubview(label)
        
        NSLayoutConstraint.activate([
            itemView.heightAnchor.constraint(greaterThanOrEqualToConstant: 44),
            
            checkbox.leadingAnchor.constraint(equalTo: itemView.leadingAnchor),
            checkbox.centerYAnchor.constraint(equalTo: itemView.centerYAnchor),
            checkbox.widthAnchor.constraint(equalToConstant: 24),
            checkbox.heightAnchor.constraint(equalToConstant: 24),
            
            label.leadingAnchor.constraint(equalTo: checkbox.trailingAnchor, constant: 12),
            label.trailingAnchor.constraint(equalTo: itemView.trailingAnchor),
            label.centerYAnchor.constraint(equalTo: itemView.centerYAnchor),
            label.topAnchor.constraint(equalTo: itemView.topAnchor, constant: 12),
            label.bottomAnchor.constraint(equalTo: itemView.bottomAnchor, constant: -12)
        ])
        
        return itemView
    }
    
    private func createSeparatorView() -> UIView {
        let separator = UIView()
        separator.translatesAutoresizingMaskIntoConstraints = false
        separator.backgroundColor = .systemGray5
        separator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        return separator
    }
}
