import UIKit

class NoteDetailViewController: UIViewController, UITextViewDelegate {

    var fullDateString: String? // Expected format: "8 October 2025 16:25"
    
    // UI: The Header Date Label (Bold, Big)
    private let dateHeaderLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .bold) // Larger bold font
        label.textColor = .black
        label.numberOfLines = 1
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    // UI: The Time Label (Small, below date)
    private let timeLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = .black
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    // UI: The Container for the text (White box with purple border option)
    private let textContainer: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        // Optional: Add the purple border seen in screenshot
        // view.layer.borderColor = UIColor.systemPurple.cgColor
        // view.layer.borderWidth = 2.0
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    // UI: The actual Text View
    private lazy var textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 16)
        tv.backgroundColor = .clear
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.delegate = self // Important for placeholder logic
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.97, alpha: 1.0)
        
        // Remove "Back" text from navbar
        navigationItem.largeTitleDisplayMode = .never
        
        setupLayout()
        configureData()
        setupPlaceholder()
    }
    
    private func setupLayout() {
        view.addSubview(dateHeaderLabel)
        view.addSubview(timeLabel)
        view.addSubview(textContainer)
        textContainer.addSubview(textView)
        
        NSLayoutConstraint.activate([
            // Date Header
            dateHeaderLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            dateHeaderLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            dateHeaderLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Time Label (Just below Date)
            timeLabel.topAnchor.constraint(equalTo: dateHeaderLabel.bottomAnchor, constant: 5),
            timeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            
            // Text Container
            textContainer.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 20),
            textContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textContainer.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            
            // Text View inside Container
            textView.topAnchor.constraint(equalTo: textContainer.topAnchor, constant: 16),
            textView.leadingAnchor.constraint(equalTo: textContainer.leadingAnchor, constant: 16),
            textView.trailingAnchor.constraint(equalTo: textContainer.trailingAnchor, constant: -16),
            textView.bottomAnchor.constraint(equalTo: textContainer.bottomAnchor, constant: -16)
        ])
    }
    
    private func configureData() {
        guard let fullString = fullDateString else { return }
        
        // Logic: Split "8 October 2025 16:25" into Date and Time
        // We assume the last component is the time.
        let components = fullString.components(separatedBy: " ")
        
        if let timeComponent = components.last {
            // Set Time
            timeLabel.text = timeComponent
            
            // Set Date (Join the rest of the components back together)
            let dateComponents = components.dropLast()
            dateHeaderLabel.text = dateComponents.joined(separator: " ")
        } else {
            // Fallback if format is weird
            dateHeaderLabel.text = fullString
        }
    }
    
    // MARK: - Placeholder Logic
    
    private func setupPlaceholder() {
        textView.text = "Write your notes here"
        textView.textColor = .lightGray
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .lightGray {
            textView.text = nil
            textView.textColor = .black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Write your notes here"
            textView.textColor = .lightGray
        }
    }
}
