//
//  FineMotorSkillsViewController.swift
//  FineMotorSkills
//
//  Created by Alishri Poddar on 27/11/25.
//

import UIKit

// MARK: - Models
//struct Question {
//    let id: Int
//    let text: String
//    let options: [String]
//    var selectedOptionIndex: Int?
//}

// MARK: - Main View Controller
class FineMotorSkillsViewController: UIViewController {

    // MARK: - Data
    var questions: [Question] = [
        Question(
            id: 1,
            text: "Which object helps you practice finger control?",
            options: ["Pencil", "Football", "Blanket", "Plate"],
            selectedOptionIndex: nil
        ),
        Question(
            id: 2,
            text: "Which action needs good hand-eye coordination?",
            options: ["Buttoning your shirt", "Running", "Listening to music", "Jumping"],
            selectedOptionIndex: nil
        ),
        Question(
            id: 3,
            text: "What do you use to pick up small beads?",
            options: ["Fingers", "Feet", "Elbow", "Knee"],
            selectedOptionIndex: nil
        )
    ]
    
    var currentQuestionIndex = 0
    
    // MARK: - UI Elements
    
    // 1. Background
    lazy var gradientBackground: GradientView = {
        let v = GradientView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    // 2. Progress Bar
    let progressBar: UIProgressView = {
        let pv = UIProgressView(progressViewStyle: .default)
        pv.trackTintColor = UIColor.white.withAlphaComponent(0.3)
        pv.progressTintColor = .white
        pv.translatesAutoresizingMaskIntoConstraints = false
        return pv
    }()
    
    // 3. Question Container
    let questionContainer: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        v.layer.cornerRadius = 25
        v.translatesAutoresizingMaskIntoConstraints = false
        // Shadow
        v.layer.shadowColor = UIColor.black.cgColor
        v.layer.shadowOpacity = 0.05
        v.layer.shadowOffset = CGSize(width: 0, height: 2)
        v.layer.shadowRadius = 4
        return v
    }()
    
    let questionLabel: UILabel = {
        let lbl = UILabel()
        lbl.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        lbl.textColor = .black
        lbl.numberOfLines = 0
        lbl.translatesAutoresizingMaskIntoConstraints = false
        return lbl
    }()
    
    // 4. Options Container
    let optionsContainer: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        v.layer.cornerRadius = 25
        v.clipsToBounds = true
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let optionsStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    // 5. Next Button
    let nextButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Next", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        btn.backgroundColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1)
        btn.setTitleColor(.white, for: .normal)
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
        setupUI()
        forceApplyTopSpacing()
        loadQuestion(at: currentQuestionIndex)
    }
    
    // MARK: - Layout Fixes
    func forceApplyTopSpacing() {
        guard let superview = progressBar.superview else { return }
        progressBar.translatesAutoresizingMaskIntoConstraints = false
        
        for constraint in superview.constraints {
            let isTopConstraint = (constraint.firstItem as? UIView == progressBar && constraint.firstAttribute == .top) ||
                                  (constraint.secondItem as? UIView == progressBar && constraint.secondAttribute == .top)
            if isTopConstraint { constraint.isActive = false }
        }
        
        let newTopConstraint = progressBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 13)
        newTopConstraint.isActive = true
        view.layoutIfNeeded()
    }
    
    func setupNavigationBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        self.title = "Fine Motor Skills"
        
        let backImage = UIImage(systemName: "chevron.left")
        let backButtonItem = UIBarButtonItem(image: backImage, style: .plain, target: self, action: #selector(backButtonTapped))
        backButtonItem.tintColor = .white
        navigationItem.leftBarButtonItem = backButtonItem
    }
    
    func setupUI() {
        view.addSubview(gradientBackground)
        view.addSubview(progressBar)
        view.addSubview(questionContainer)
        questionContainer.addSubview(questionLabel)
        view.addSubview(optionsContainer)
        optionsContainer.addSubview(optionsStack)
        view.addSubview(nextButton)
        
        nextButton.addTarget(self, action: #selector(nextButtonTapped), for: .touchUpInside)
        
        NSLayoutConstraint.activate([
            // Background
            gradientBackground.topAnchor.constraint(equalTo: view.topAnchor),
            gradientBackground.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            gradientBackground.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientBackground.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            // Progress Bar
            progressBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            progressBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            progressBar.heightAnchor.constraint(equalToConstant: 4),
            
            // Question Container
            questionContainer.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 30),
            questionContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            questionContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            questionContainer.heightAnchor.constraint(greaterThanOrEqualToConstant: 60),
            
            questionLabel.topAnchor.constraint(equalTo: questionContainer.topAnchor, constant: 20),
            questionLabel.bottomAnchor.constraint(equalTo: questionContainer.bottomAnchor, constant: -20),
            questionLabel.leadingAnchor.constraint(equalTo: questionContainer.leadingAnchor, constant: 20),
            questionLabel.trailingAnchor.constraint(equalTo: questionContainer.trailingAnchor, constant: -20),
            
            // Options Container
            optionsContainer.topAnchor.constraint(equalTo: questionContainer.bottomAnchor, constant: 20),
            optionsContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            optionsContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            optionsStack.topAnchor.constraint(equalTo: optionsContainer.topAnchor),
            optionsStack.bottomAnchor.constraint(equalTo: optionsContainer.bottomAnchor),
            optionsStack.leadingAnchor.constraint(equalTo: optionsContainer.leadingAnchor),
            optionsStack.trailingAnchor.constraint(equalTo: optionsContainer.trailingAnchor),
            
            // Next Button
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            nextButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            nextButton.heightAnchor.constraint(equalToConstant: 55)
        ])
    }
    
    // MARK: - Logic
    func loadQuestion(at index: Int) {
        guard index < questions.count else { return }
        let question = questions[index]
        
        questionLabel.text = "\(question.id). \(question.text)"
        
        let hasSelection = question.selectedOptionIndex != nil
        updateProgress(hasSelected: hasSelection)
        
        let title = (index == questions.count - 1) ? "Finish" : "Next"
        nextButton.setTitle(title, for: .normal)
        nextButton.alpha = hasSelection ? 1.0 : 0.6
        
        optionsStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        for (i, optionText) in question.options.enumerated() {
            let isLast = i == question.options.count - 1
            let radioView = RadioOptionView1(text: optionText, showSeparator: !isLast)
            radioView.tag = i
            radioView.isSelectedOption = (i == question.selectedOptionIndex)
            
            radioView.onSelect = { [weak self] in
                self?.optionSelected(index: i)
            }
            optionsStack.addArrangedSubview(radioView)
        }
    }
    
    func updateProgress(hasSelected: Bool) {
        let total = Float(questions.count)
        let currentBase = Float(currentQuestionIndex)
        let visualIndex = currentBase + (hasSelected ? 1.0 : 0.0)
        let progress = visualIndex / total
        progressBar.setProgress(progress, animated: true)
    }
    
    // MARK: - Actions
    func optionSelected(index: Int) {
        questions[currentQuestionIndex].selectedOptionIndex = index
        for view in optionsStack.arrangedSubviews {
            if let radioView = view as? RadioOptionView1 {
                radioView.isSelectedOption = (radioView.tag == index)
            }
        }
        nextButton.alpha = 1.0
        updateProgress(hasSelected: true)
    }
    
    @objc func backButtonTapped() {
        if currentQuestionIndex > 0 {
            currentQuestionIndex -= 1
            loadQuestion(at: currentQuestionIndex)
        } else {
            if let nav = navigationController { nav.popViewController(animated: true) }
            else { dismiss(animated: true, completion: nil) }
        }
    }
    
    @objc func nextButtonTapped() {
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
            loadQuestion(at: currentQuestionIndex)
        } else {
            print("Assessment Submitted")
            if let nav = navigationController { nav.popViewController(animated: true) }
            else { dismiss(animated: true, completion: nil) }
        }
    }
}
