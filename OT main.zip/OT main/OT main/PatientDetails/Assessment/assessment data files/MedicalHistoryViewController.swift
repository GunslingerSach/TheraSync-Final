import UIKit

// MARK: - Data Model
struct MedicalCondition {
    let name: String
    var isActive: Bool
}

// MARK: - Custom Table View Cell
class MedicalConditionCell: UITableViewCell {
    
    static let identifier = "MedicalConditionCell"
    
    // MARK: - UI Components
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let label: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .medium)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let statusIcon: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.tintColor = .systemGray4
        return iv
    }()
    
    // MARK: - Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none
        
        contentView.addSubview(containerView)
        containerView.addSubview(label)
        containerView.addSubview(statusIcon)
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            label.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),
            label.trailingAnchor.constraint(lessThanOrEqualTo: statusIcon.leadingAnchor, constant: -10),
            
            statusIcon.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            statusIcon.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),
            statusIcon.widthAnchor.constraint(equalToConstant: 24),
            statusIcon.heightAnchor.constraint(equalToConstant: 24)
        ])
    }
    
    // MARK: - Configuration
    func configure(with condition: MedicalCondition) {
        label.text = condition.name
        
        let config = UIImage.SymbolConfiguration(weight: .semibold)
        
        if condition.isActive {
            statusIcon.image = UIImage(systemName: "checkmark.circle.fill", withConfiguration: config)
            statusIcon.tintColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.0)
            label.textColor = .label
        } else {
            statusIcon.image = UIImage(systemName: "circle", withConfiguration: config)
            statusIcon.tintColor = .systemGray3
            label.textColor = .secondaryLabel
        }
    }
}

// MARK: - Main View Controller
class MedicalHistoryViewController: UIViewController {
    
    // MARK: - Data
    // Updated: Diabetes is now false by default
    private var conditions: [MedicalCondition] = [
        MedicalCondition(name: "Hypertension", isActive: false),
        MedicalCondition(name: "Diabetes", isActive: false),
        MedicalCondition(name: "Asthma", isActive: false),
        MedicalCondition(name: "Epilepsy", isActive: false),
        MedicalCondition(name: "Heart Disease", isActive: false),
        MedicalCondition(name: "Allergies", isActive: false),
        MedicalCondition(name: "Gastric Ulcers", isActive: false),
        MedicalCondition(name: "Dental Treatment", isActive: false),
        MedicalCondition(name: "Low Blood Pressure", isActive: false)
    ]
    
    // MARK: - UI Components
    
    private let listContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 24
        view.layer.cornerCurve = .continuous
        
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 0, height: 10)
        view.layer.shadowOpacity = 0.05
        view.layer.shadowRadius = 20
        
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.backgroundColor = .clear
        tv.separatorStyle = .singleLine
        tv.separatorColor = .systemGray6
        tv.separatorInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.delegate = self
        tv.dataSource = self
        tv.register(MedicalConditionCell.self, forCellReuseIdentifier: MedicalConditionCell.identifier)
        tv.tableFooterView = UIView()
        return tv
    }()
    
    private let doneButton: UIButton = {
        let button = UIButton(type: .system)
        
        var config = UIButton.Configuration.filled()
        config.title = "Done"
        config.baseBackgroundColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.0)
        config.baseForegroundColor = .white
        config.cornerStyle = .capsule
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var outgoing = incoming
            outgoing.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
            return outgoing
        }
        
        button.configuration = config
        button.translatesAutoresizingMaskIntoConstraints = false
        
        button.layer.shadowColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.0).cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 8)
        button.layer.shadowOpacity = 0.3
        button.layer.shadowRadius = 12
        return button
    }()
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    
    // MARK: - Lifecycle
    
    // 1. Set the GradientView as the main view
    override func loadView() {
        let gradientView = GradientView()
        self.view = gradientView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Medical History"
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavigationBar()
    }
    
    // 2. Configure Transparent Nav Bar with White Text
    private func configureNavigationBar() {
        navigationController?.setNavigationBarHidden(false, animated: true)
        
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
    }
    
    // MARK: - Setup UI
    private func setupUI() {
        // Note: We removed headerView, titleLabel, backButton (Nav bar handles them)
        
        view.addSubview(listContainerView)
        listContainerView.addSubview(tableView)
        view.addSubview(doneButton)
        
        doneButton.addTarget(self, action: #selector(didTapDone), for: .touchUpInside)
        
        let rowHeight: CGFloat = 60.0
        let tableContentHeight = (CGFloat(conditions.count) * rowHeight) + 20.0
        
        let safe = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            // List Container
            // Pins to Top Safe Area (Nav bar is transparent, so this sits below it)
            listContainerView.topAnchor.constraint(equalTo: safe.topAnchor, constant: 20),
            listContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            listContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Height Logic
            listContainerView.heightAnchor.constraint(equalToConstant: tableContentHeight),
            // Ensure it doesn't go behind the done button
            listContainerView.bottomAnchor.constraint(lessThanOrEqualTo: doneButton.topAnchor, constant: -30),
            
            // TableView
            tableView.topAnchor.constraint(equalTo: listContainerView.topAnchor, constant: 10),
            tableView.leadingAnchor.constraint(equalTo: listContainerView.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: listContainerView.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: listContainerView.bottomAnchor, constant: -10),
            
            // Done Button
            doneButton.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -20),
            doneButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            doneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            doneButton.heightAnchor.constraint(equalToConstant: 56)
        ])
    }
    
    @objc private func didTapDone() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - TableView Delegate & DataSource
extension MedicalHistoryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conditions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: MedicalConditionCell.identifier, for: indexPath) as? MedicalConditionCell else {
            return UITableViewCell()
        }
        
        let condition = conditions[indexPath.row]
        cell.configure(with: condition)
        
        // Remove separator for the last cell
        if indexPath.row == conditions.count - 1 {
            cell.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: .greatestFiniteMagnitude)
        } else {
            cell.separatorInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        conditions[indexPath.row].isActive.toggle()
        impactFeedback.impactOccurred()
        tableView.reloadRows(at: [indexPath], with: .automatic)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
