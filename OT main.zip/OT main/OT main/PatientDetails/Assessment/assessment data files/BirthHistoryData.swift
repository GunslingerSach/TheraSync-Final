//
//  BirthHistoryData.swift
//  AssesmentThera
//
//  Created by user@54 on 25/11/25.
//

import Foundation

struct BirthHistoryData {
    static let rows: [String] = [
        "Gestational Age",
        "Delivery",
        "Birth Weight",
        "Birth Order",
        "Complications"
    ]
}
