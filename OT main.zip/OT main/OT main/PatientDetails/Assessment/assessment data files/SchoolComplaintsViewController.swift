//
//  SchoolComplaintsViewController.swift
//  AssesmentThera
//
//  Created by user@54 on 25/11/25.
//

import UIKit

final class SchoolComplaintsViewController: UIViewController {

    private let cardShadowContainer: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.shadowColor = UIColor.black.cgColor
        v.layer.shadowOpacity = 0.08
        v.layer.shadowRadius = 10
        v.layer.shadowOffset = CGSize(width: 0, height: 6)
        v.backgroundColor = .clear
        return v
    }()

    private let cardInner: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 18
        v.layer.masksToBounds = true
        return v
    }()

    private let tableView: UITableView = {
        let tv = UITableView(frame: .zero, style: .plain)
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.separatorStyle = .none
        tv.backgroundColor = .clear
        tv.estimatedRowHeight = 60
        tv.rowHeight = UITableView.automaticDimension
        tv.isScrollEnabled = false // Disable scrolling, let card expand
        return tv
    }()

    private let doneButton: UIButton = {
        let b = UIButton(type: .system)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.setTitle("Done", for: .normal)
        b.setTitleColor(.white, for: .normal)
        b.backgroundColor = UIColor.systemBlue
        b.layer.cornerRadius = 26
        b.clipsToBounds = true
        return b
    }()

    private var values: [Int: String] = [:]

    // MARK: - Lifecycle
    
    // --- CHANGE: Set GradientView as main view ---
    override func loadView() {
        self.view = GradientView()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "School Complaints"
        
        // Configure Transparent Nav Bar
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
        
        setupUI()
        setupTable()
        registerKeyboardNotifications()
    }

    deinit { unregisterKeyboardNotifications() }

    private func setupUI() {

        view.addSubview(cardShadowContainer)
        cardShadowContainer.addSubview(cardInner)
        cardInner.addSubview(tableView)
        view.addSubview(doneButton)

        let safe = view.safeAreaLayoutGuide
        
        // Calculate height dynamically
        let tableHeight = CGFloat(SchoolComplaintsData.rows.count) * 50.0

        NSLayoutConstraint.activate([
            cardShadowContainer.topAnchor.constraint(equalTo: safe.topAnchor, constant: 20),
            cardShadowContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            cardShadowContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            cardInner.topAnchor.constraint(equalTo: cardShadowContainer.topAnchor),
            cardInner.leadingAnchor.constraint(equalTo: cardShadowContainer.leadingAnchor),
            cardInner.trailingAnchor.constraint(equalTo: cardShadowContainer.trailingAnchor),
            cardInner.bottomAnchor.constraint(equalTo: cardShadowContainer.bottomAnchor),

            tableView.topAnchor.constraint(equalTo: cardInner.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: cardInner.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: cardInner.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: cardInner.bottomAnchor),
            
            // Force height constraint so card fits table exactly
            tableView.heightAnchor.constraint(equalToConstant: tableHeight),

            doneButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            doneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            doneButton.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -20),
            doneButton.heightAnchor.constraint(equalToConstant: 52)
        ])

        doneButton.addTarget(self, action: #selector(doneTapped), for: .touchUpInside)
    }

    private func setupTable() {
        tableView.dataSource = self
        tableView.delegate = self
        // Using the shared TextFieldCell you already have
        tableView.register(TextFieldCell.self, forCellReuseIdentifier: TextFieldCell.identifier)
    }

    @objc private func doneTapped() {
        var result: [String: String] = [:]
        for (index, label) in SchoolComplaintsData.rows.enumerated() {
            result[label] = values[index] ?? ""
        }
        print("School Complaints:", result)
        navigationController?.popViewController(animated: true)
    }

    // keyboard handling
    private func registerKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(kbShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(kbHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    private func unregisterKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func kbShow(_ n: Notification) {
        guard let frame = n.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        let h = frame.height - view.safeAreaInsets.bottom + 12
        tableView.contentInset.bottom = h
        tableView.verticalScrollIndicatorInsets.bottom = h
    }

    @objc private func kbHide(_ n: Notification) {
        tableView.contentInset.bottom = 0
        tableView.verticalScrollIndicatorInsets.bottom = 0
    }
}

extension SchoolComplaintsViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        SchoolComplaintsData.rows.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50 // Fixed height
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: TextFieldCell.identifier, for: indexPath) as! TextFieldCell

        let placeholder = SchoolComplaintsData.rows[indexPath.row]
        let currentValue = values[indexPath.row]

        cell.configure(placeholder: placeholder, value: currentValue)
        cell.setRoundedCorners(isFirst: indexPath.row == 0, isLast: indexPath.row == SchoolComplaintsData.rows.count - 1)
        cell.showSeparator(indexPath.row != SchoolComplaintsData.rows.count - 1)

        cell.textField.tag = indexPath.row
        cell.textField.addTarget(self, action: #selector(textChanged(_:)), for: .editingChanged)

        return cell
    }

    @objc private func textChanged(_ tf: UITextField) {
        values[tf.tag] = tf.text
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? TextFieldCell {
            cell.becomeTextFieldFirstResponder()
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
