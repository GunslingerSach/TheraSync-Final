//
//  SchoolComplaintsData.swift
//  AssesmentThera
//
//  Created by user@54 on 25/11/25.
//

import Foundation

struct SchoolComplaintsData {
    static let rows: [String] = [
        "Attention / Focus Issues",
        "Sitting Tolerance",
        "Writing / Handwriting Concerns",
        "Academic Performance",
        "Behavioural Concerns"
    ]
}
