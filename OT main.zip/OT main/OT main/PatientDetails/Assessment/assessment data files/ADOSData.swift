//
//  ADOSData.swift
//  AssesmentThera
//
//  Created by user@54 on 21/11/25.
//

import Foundation

// MARK: - Model
struct ADOSQuestion {
    let id: Int
    let question: String
    let options: [String]
}

// MARK: - ADOS Question Set
struct ADOSData {

    static let questions: [ADOSQuestion] = [

        ADOSQuestion(
            id: 1,
            question: "I prefer to do things on my own, rather than with others.",
            options: [
                "Definitely Agree",
                "Slightly Agree",
                "Slightly Disagree",
                "Definitely Disagree"
            ]
        ),

        ADOSQuestion(
            id: 2,
            question: "I prefer doing things the same way – for instance my morning routine or trip to the supermarket.",
            options: [
                "Definitely Agree",
                "Slightly Agree",
                "Slightly Disagree",
                "Definitely Disagree"
            ]
        ),

        ADOSQuestion(
            id: 3,
            question: "I find myself strongly absorbed in something – even obsessional.",
            options: [
                "Definitely Agree",
                "Slightly Agree",
                "Slightly Disagree",
                "Definitely Disagree"
            ]
        ),

        ADOSQuestion(
            id: 4,
            question: "I am very sensitive to noise and will wear earplugs or cover my ears in certain situations.",
            options: [
                "Definitely Agree",
                "Slightly Agree",
                "Slightly Disagree",
                "Definitely Disagree"
            ]
        ),

        ADOSQuestion(
            id: 5,
            question: "Sometimes people say I am rude, even though I think I am being polite.",
            options: [
                "Definitely Agree",
                "Slightly Agree",
                "Slightly Disagree",
                "Definitely Disagree"
            ]
        )
    ]
}
