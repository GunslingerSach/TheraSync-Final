import UIKit

class PatientDifficultiesViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var optionsStackView: UIStackView!
    @IBOutlet weak var nextButton: UIButton!
    
    // MARK: - Data Models
    struct Question {
        let text: String
        let options: [String]
    }
    
    // MARK: - State
    var questions: [Question] = [
        Question(text: "1. I have problems with daily tasks like (brushing, wearing clothes...etc)", options: ["Yes", "No", "Sometimes"]),
        Question(text: "2. I have trouble while sleeping", options: ["Nightly", "A few times a week", "Rarely"]),
        Question(text: "3. I tend to forget things", options: ["Often", "Occasionally", "Unsure"])
    ]
    
    var userAnswers: [Int: Int] = [:]
    var currentQuestionIndex = 0
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
        setupUI()
        
        // Apply the constraint fix
        forceApplyTopSpacing()
        
        loadQuestion(at: currentQuestionIndex)
    }
    
    // MARK: - Programmatic Layout Fix (Aggressive)
    func forceApplyTopSpacing() {
        guard let superview = progressBar.superview else { return }
        
        progressBar.translatesAutoresizingMaskIntoConstraints = false
        
        // Remove old constraints
        for constraint in superview.constraints {
            let isTopConstraint = (constraint.firstItem as? UIView == progressBar && constraint.firstAttribute == .top) ||
                                  (constraint.secondItem as? UIView == progressBar && constraint.secondAttribute == .top)
            
            if isTopConstraint {
                constraint.isActive = false
            }
        }
        
        // New exact constraint (13 points)
        let newTopConstraint = progressBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 13)
        newTopConstraint.isActive = true
        
        view.layoutIfNeeded()
    }
    
    // MARK: - Setup UI
    func setupNavBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        self.title = "Patient's Difficulties"
        
        let backImage = UIImage(systemName: "chevron.left")
        let backButtonItem = UIBarButtonItem(image: backImage, style: .plain, target: self, action: #selector(backButtonTapped))
        backButtonItem.tintColor = .black
        
        navigationItem.leftBarButtonItem = backButtonItem
    }
    
    func setupUI() {
        // --- FONT UPDATE HERE ---
        // Sets the question text to be Bold and Larger (22pt) to match your image
        questionLabel.font = .systemFont(ofSize: 18, weight: .medium)
        questionLabel.textColor = .black
        
        
        // Button Styling
        nextButton.layer.cornerRadius = 25
        nextButton.backgroundColor = .systemBlue
        nextButton.setTitleColor(.white, for: .normal)
        nextButton.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold)
        
        // Progress Bar Styling
        progressBar.trackTintColor = UIColor.white.withAlphaComponent(0.3)
        progressBar.progressTintColor = .white
        progressBar.setProgress(0, animated: false)

        // Container Styling
        optionsStackView.layer.cornerRadius = 25
        optionsStackView.clipsToBounds = true
        questionLabel.superview?.layer.cornerRadius = 25
    }
    
    // MARK: - Logic
    func loadQuestion(at index: Int) {
        guard index < questions.count else { return }
        
        let question = questions[index]
        questionLabel.text = question.text
        
        let previousAnswerIndex = userAnswers[index]
        updateProgress(hasSelected: previousAnswerIndex != nil)
        setupOptions(for: question.options, selectedIndex: previousAnswerIndex)
        
        let title = (index == questions.count - 1) ? "Submit" : "Next"
        nextButton.setTitle(title, for: .normal)
        
        nextButton.isEnabled = (previousAnswerIndex != nil)
        nextButton.alpha = (previousAnswerIndex != nil) ? 1.0 : 0.5
    }
    
    func setupOptions(for options: [String], selectedIndex: Int?) {
        optionsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        for (index, optionText) in options.enumerated() {
            let radioView = RadioOptionView()
            radioView.optionLabel.text = optionText
            radioView.tag = index
            radioView.addTarget(self, action: #selector(optionSelected(_:)), for: .touchUpInside)
            
            if let selectedIndex = selectedIndex, index == selectedIndex {
                radioView.isOn = true
            }
            
            if index == options.count - 1 {
                radioView.showSeparator(false)
            }
            
            radioView.translatesAutoresizingMaskIntoConstraints = false
            radioView.heightAnchor.constraint(equalToConstant: 56).isActive = true
            optionsStackView.addArrangedSubview(radioView)
        }
    }
    
    func updateProgress(hasSelected: Bool) {
        let total = Float(questions.count)
        let currentBase = Float(currentQuestionIndex)
        let visualIndex = currentBase + (hasSelected ? 1.0 : 0.0)
        let progress = visualIndex / total
        progressBar.setProgress(progress, animated: true)
    }

    // MARK: - Actions
    @objc func optionSelected(_ sender: RadioOptionView) {
        optionsStackView.arrangedSubviews.forEach { view in
            if let radioView = view as? RadioOptionView {
                radioView.isOn = (radioView == sender)
            }
        }
        
        userAnswers[currentQuestionIndex] = sender.tag
        updateProgress(hasSelected: true)
        
        nextButton.isEnabled = true
        nextButton.alpha = 1.0
    }

    @IBAction func nextButtonTapped(_ sender: UIButton) {
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
            loadQuestion(at: currentQuestionIndex)
        } else {
            print("Assessment Submitted: \(userAnswers)")
            navigationController?.popViewController(animated: true)
        }
    }
    
    @objc func backButtonTapped() {
        if currentQuestionIndex > 0 {
            currentQuestionIndex -= 1
            loadQuestion(at: currentQuestionIndex)
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
}
