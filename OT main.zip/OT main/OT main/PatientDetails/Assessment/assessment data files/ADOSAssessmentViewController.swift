//
//  ADOSAssessmentViewController.swift
//  AssesmentThera
//
//  Created by user@54 on 21/11/25.
//

// ADOSAssessmentViewController.swift
// Replace your current file with this one.

import UIKit

final class ADOSAssessmentViewController: UIViewController {

    // Full-screen gradient background (assumes ProgrammaticGradientView exists)
    private let backgroundGradient: GradientView = {
        let v = GradientView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    // Progress under title/back
    private let progressView: UIProgressView = {
        let pv = UIProgressView(progressViewStyle: .default)
        pv.translatesAutoresizingMaskIntoConstraints = false
        pv.trackTintColor = UIColor(red: 0, green: 0, blue: 0.92, alpha: 1)
        pv.tintColor = UIColor.white
        pv.layer.cornerRadius = 3
        pv.clipsToBounds = true
        pv.progress = 0
        return pv
    }()

    // Question pill
    private let questionContainer: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 18
        v.layer.masksToBounds = true
        return v
    }()
    private let questionLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        l.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        l.textColor = .black
        return l
    }()

    // Options card
    private let cardContainerView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 18
        v.layer.shadowColor = UIColor.black.withAlphaComponent(0.06).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 6)
        v.layer.shadowRadius = 12
        v.layer.shadowOpacity = 1.0
        return v
    }()

    private let optionsTableView: UITableView = {
        let tv = UITableView(frame: .zero, style: .plain)
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.backgroundColor = .clear
        tv.separatorStyle = .none
        tv.estimatedRowHeight = 64
        tv.rowHeight = UITableView.automaticDimension
        tv.tableFooterView = UIView()
        return tv
    }()

    // Next button
    private let nextButton: UIButton = {
        let b = UIButton(type: .system)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.setTitle("Next", for: .normal)
        b.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        b.setTitleColor(.white, for: .normal)
        b.layer.cornerRadius = 28
        b.clipsToBounds = true
        // IMPORTANT: start visually faded (but we'll not use alpha to show enabled/disabled),
        // instead we use different gradient color sets.
        b.isEnabled = false
        return b
    }()

    // Data
    private var currentIndex = 0 { didSet { updateProgressAndUI() } }
    private var selectedAnswers: [Int: Int] = [:]

    // Gradient layer for Next button (we'll change its colors depending on state)
    private var nextGradientLayer: CAGradientLayer?
    
func setupNavBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        self.title = "ADOS"
        
        let backImage = UIImage(systemName: "chevron.left")
        let backButtonItem = UIBarButtonItem(image: backImage, style: .plain, target: self, action: #selector(backButtonTapped))
        backButtonItem.tintColor = .black
        
        navigationItem.leftBarButtonItem = backButtonItem
    }
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // background gradient full screen
        view.addSubview(backgroundGradient)
        NSLayoutConstraint.activate([
            backgroundGradient.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundGradient.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundGradient.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundGradient.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        setupNavBar()
        setupViews()
        setupTable()
        loadQuestion(animated: false)

        // initial button appearance (disabled)
        updateNextButtonAppearance(hasSelection: false, animated: false)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // hide the system navigation bar to avoid duplicate chrome
        navigationController?.setNavigationBarHidden(false, animated: false)
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
        navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
        navigationController?.navigationBar.shadowImage = nil
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // ensure gradient layer covers button bounds
        ensureNextGradientLayer()
    }
    @objc func backButtonTapped() {
            navigationController?.popViewController(animated: true)
    }
    // MARK: - Setup
    private func setupViews() {
        view.addSubview(progressView)

        view.addSubview(questionContainer)
        questionContainer.addSubview(questionLabel)

        view.addSubview(cardContainerView)
        cardContainerView.addSubview(optionsTableView)

        view.addSubview(nextButton)

        let safe = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            // top row

            progressView.topAnchor.constraint(equalTo: safe.topAnchor, constant: 12),
            progressView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            progressView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            progressView.heightAnchor.constraint(equalToConstant: 6),

            // question pill
            questionContainer.topAnchor.constraint(equalTo: progressView.bottomAnchor, constant: 14),
            questionContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            questionContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            questionContainer.heightAnchor.constraint(greaterThanOrEqualToConstant: 64),

            questionLabel.topAnchor.constraint(equalTo: questionContainer.topAnchor, constant: 12),
            questionLabel.leadingAnchor.constraint(equalTo: questionContainer.leadingAnchor, constant: 16),
            questionLabel.trailingAnchor.constraint(equalTo: questionContainer.trailingAnchor, constant: -16),
            questionLabel.bottomAnchor.constraint(equalTo: questionContainer.bottomAnchor, constant: -12),

            // card with options
            cardContainerView.topAnchor.constraint(equalTo: questionContainer.bottomAnchor, constant: 18),
            cardContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            cardContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            cardContainerView.heightAnchor.constraint(greaterThanOrEqualToConstant: 220),

            optionsTableView.topAnchor.constraint(equalTo: cardContainerView.topAnchor, constant: 8),
            optionsTableView.leadingAnchor.constraint(equalTo: cardContainerView.leadingAnchor),
            optionsTableView.trailingAnchor.constraint(equalTo: cardContainerView.trailingAnchor),
            optionsTableView.bottomAnchor.constraint(equalTo: cardContainerView.bottomAnchor, constant: -8),

            // bottom next button
            nextButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            nextButton.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -20),
            nextButton.heightAnchor.constraint(equalToConstant: 56)
        ])

        nextButton.addTarget(self, action: #selector(nextTapped(_:)), for: .touchUpInside)

        // add pressed state animations
        nextButton.addTarget(self, action: #selector(nextTouchDown(_:)), for: .touchDown)
        nextButton.addTarget(self, action: #selector(nextTouchUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
    }

    private func setupTable() {
        optionsTableView.dataSource = self
        optionsTableView.delegate = self
        optionsTableView.register(RadioOptionCell.self, forCellReuseIdentifier: RadioOptionCell.identifier)
    }

    // MARK: - Next button gradient helpers

    private func ensureNextGradientLayer() {
        if nextGradientLayer == nil {
            let g = CAGradientLayer()
            g.startPoint = CGPoint(x: 0, y: 0)
            g.endPoint   = CGPoint(x: 1, y: 1)
            g.cornerRadius = 28
            g.frame = nextButton.bounds
            nextButton.layer.insertSublayer(g, at: 0)
            nextGradientLayer = g
            // initial colors set by updateNextButtonAppearance
        } else {
            nextGradientLayer?.frame = nextButton.bounds
        }
    }

    /// Call this whenever selection state changes.
    private func updateNextButtonAppearance(hasSelection: Bool, animated: Bool = true) {
        // update enabled state
        nextButton.isEnabled = hasSelection

        // colors for enabled (strong) and disabled (faded)
        let enabledColors: [CGColor] = [
            UIColor(red: 0.20, green: 0.56, blue: 0.99, alpha: 1).cgColor,
            UIColor(red: 0.18, green: 0.49, blue: 0.95, alpha: 1).cgColor
        ]
        let disabledColors: [CGColor] = [
            UIColor(red: 0.78, green: 0.86, blue: 0.94, alpha: 1).cgColor,  // visible light blue
            UIColor(red: 0.74, green: 0.84, blue: 0.93, alpha: 1).cgColor   // soft gradient bottom
        ]


        ensureNextGradientLayer()

        // animate color transition
        if animated {
            let animation = CABasicAnimation(keyPath: "colors")
            animation.duration = 0.22
            animation.fromValue = nextGradientLayer?.colors
            animation.toValue = hasSelection ? enabledColors : disabledColors
            animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            nextGradientLayer?.add(animation, forKey: "colors")
            nextGradientLayer?.colors = hasSelection ? enabledColors : disabledColors
        } else {
            nextGradientLayer?.colors = hasSelection ? enabledColors : disabledColors
        }

        // subtle title color change if desired
        nextButton.setTitleColor(hasSelection ? .white : UIColor(white: 1.0, alpha: 0.9), for: .normal)

        // keep the button visually opaque even when disabled (Figma uses faded gradient, not reduced alpha)
        nextButton.alpha = 1.0
    }

    // MARK: - Actions (touch animations)
    @objc private func nextTouchDown(_ sender: UIButton) {
        guard nextButton.isEnabled else { return }
        // slightly scale down and darken
        UIView.animate(withDuration: 0.12, delay: 0, options: [.curveEaseIn], animations: {
            sender.transform = CGAffineTransform(scaleX: 0.985, y: 0.985)
            sender.alpha = 0.98
        }, completion: nil)
    }

    @objc private func nextTouchUp(_ sender: UIButton) {
        guard nextButton.isEnabled else { return }
        UIView.animate(withDuration: 0.12, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1.0, options: [], animations: {
            sender.transform = .identity
            sender.alpha = 1.0
        }, completion: nil)
    }

    // MARK: - Data / UI
    private func loadQuestion(animated: Bool) {
        guard ADOSData.questions.indices.contains(currentIndex) else { return }
        let q = ADOSData.questions[currentIndex]
        questionLabel.text = "\(q.id). \(q.question)"
        optionsTableView.reloadData()
        updateNextButtonState()
        if animated {
            UIView.transition(with: questionLabel, duration: 0.18, options: .transitionCrossDissolve, animations: nil)
        }
    }

    private func updateProgressAndUI() {
        let total = ADOSData.questions.count
        guard total > 1 else {
            progressView.setProgress(1.0, animated: true)
            return
        }
        let progress = Float(currentIndex) / Float(total - 1)
        progressView.setProgress(progress, animated: true)
        loadQuestion(animated: true)
        nextButton.setTitle(currentIndex == ADOSData.questions.count - 1 ? "Submit" : "Next", for: .normal)
    }

    private func updateNextButtonState() {
        let hasSelection = selectedAnswers[currentIndex] != nil
        updateNextButtonAppearance(hasSelection: hasSelection, animated: true)
    }

    // MARK: - Actions
    @objc private func backTapped() {
        if let nav = navigationController, nav.viewControllers.first != self {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true, completion: nil)
        }
    }

    @objc private func nextTapped(_ sender: UIButton) {
        guard nextButton.isEnabled else { return }

        if currentIndex < ADOSData.questions.count - 1 {
            currentIndex += 1
            optionsTableView.setContentOffset(.zero, animated: false)
        } else {
            let resultVC = SelectedAssessmentsViewController()
            navigationController?.pushViewController(resultVC, animated: true)
        }
    }
}

// MARK: - Table datasource / delegate
extension ADOSAssessmentViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ADOSData.questions[currentIndex].options.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(withIdentifier: RadioOptionCell.identifier, for: indexPath) as? RadioOptionCell else {
            return UITableViewCell()
        }

        let optionText = ADOSData.questions[currentIndex].options[indexPath.row]
        cell.optionLabel.text = optionText
        let isSelected = selectedAnswers[currentIndex] == indexPath.row
        cell.setSelectedState(isSelected, animated: false)

        let isLast = indexPath.row == ADOSData.questions[currentIndex].options.count - 1
        cell.showSeparator(!isLast)

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedAnswers[currentIndex] = indexPath.row
        tableView.reloadData()
        updateNextButtonState()
    }
}
