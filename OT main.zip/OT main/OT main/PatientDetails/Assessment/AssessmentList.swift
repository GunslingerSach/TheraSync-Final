import UIKit

final class AssessmentList: UIViewController {

    // MARK: - Data Variables
    var assessmentsToDisplay: [String] = [] {
        didSet {
            tableView.reloadData()
            // Layout update happens automatically via observer
        }
    }
    
    // Track visited items (Green checkmark logic)
    private var visitedAssessments: Set<String> = []

    // MARK: - UI Components
    
    private let cardView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 20
        view.layer.masksToBounds = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private let tableView = UITableView(frame: .zero, style: .plain)
    
    private let endButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("End Assessment", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.backgroundColor = .systemRed
        button.layer.cornerRadius = 25
        button.layer.masksToBounds = true
        // Initially hidden
        button.isHidden = true
        button.alpha = 0
        return button
    }()
    
    // Constraints & Observers
    private var cardHeightConstraint: NSLayoutConstraint?
    private var contentSizeObservation: NSKeyValueObservation?

    // MARK: - Lifecycle
    
    override func loadView() {
        // Assuming you have the GradientView class from previous steps
        let gradientView = GradientView()
        self.view = gradientView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Selected Assessments"
        
        setupViews()
        setupConstraints()
        
        // --- FIX: OBSERVE CONTENT SIZE ---
        // This automatically resizes the card whenever the table grows or shrinks
        contentSizeObservation = tableView.observe(\.contentSize, options: .new) { [weak self] _, _ in
            self?.updateCardHeight()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavigationBar()
        checkProgress()
        tableView.reloadData()
    }
    
    // MARK: - Dynamic Sizing Logic (THE FIX)
    
    private func updateCardLayout() {
        // Triggered by the observer
        updateCardHeight()
    }
    
    private func updateCardHeight() {
        // 1. Get the ACTUAL height of the table content
        let contentHeight = tableView.contentSize.height
        
        // 2. Calculate available space
        let safeAreaHeight = view.safeAreaLayoutGuide.layoutFrame.height
        let margins: CGFloat = 20 + 50 + 20 + 20 // Top + Button + Spacing
        let maxAvailableHeight = safeAreaHeight - margins
        
        // 3. Determine Final Height
        // If content is small, shrink wrap. If huge, cap at max.
        let finalHeight = min(contentHeight, maxAvailableHeight)
        
        // 4. Update Scrolling
        tableView.isScrollEnabled = contentHeight > maxAvailableHeight
        
        // 5. Update Constraint
        if cardHeightConstraint?.constant != finalHeight {
            cardHeightConstraint?.constant = finalHeight
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
        }
    }

    // MARK: - Progress Logic
    
    private func checkProgress() {
        let allVisited = !assessmentsToDisplay.isEmpty && visitedAssessments.count == assessmentsToDisplay.count
        
        if allVisited && endButton.isHidden {
            endButton.isHidden = false
            UIView.animate(withDuration: 0.3) {
                self.endButton.alpha = 1.0
            }
        } else if !allVisited && !endButton.isHidden {
            endButton.isHidden = true
            endButton.alpha = 0
        }
    }

    // MARK: - Setup UI
    
    private func configureNavigationBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
    }

    private func setupViews() {
        view.addSubview(cardView)
        cardView.addSubview(tableView)
        view.addSubview(endButton)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.backgroundColor = .white
        // REMOVED fixed rowHeight to allow dynamic sizing if needed
        tableView.tableFooterView = UIView()
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        
        endButton.addTarget(self, action: #selector(didTapEndAssessment), for: .touchUpInside)
    }

    private func setupConstraints() {
        let safe = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            // --- End Button (Pinned Bottom) ---
            endButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            endButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            endButton.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -20),
            endButton.heightAnchor.constraint(equalToConstant: 50),
            
            // --- Card View (Pinned Top) ---
            cardView.topAnchor.constraint(equalTo: safe.topAnchor, constant: 20),
            cardView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            cardView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            // --- Table View (Fills Card) ---
            tableView.topAnchor.constraint(equalTo: cardView.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor),
        ])
        
        // Initialize height constraint
        cardHeightConstraint = cardView.heightAnchor.constraint(equalToConstant: 50)
        cardHeightConstraint?.isActive = true
    }
    
    // MARK: - Actions
    @objc private func didTapEndAssessment() {
        navigationController?.popToRootViewController(animated: true)
    }
}

// MARK: - UITableViewDataSource / Delegate
extension AssessmentList: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return assessmentsToDisplay.count
    }

    // REMOVED fixed heightForRowAt to allow TableView to calculate natural height
    // If you strictly want 44, you can add it back, but using contentSize handles it regardless.

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        var config = cell.defaultContentConfiguration()
        let name = assessmentsToDisplay[indexPath.row]
        config.text = name
        
        if visitedAssessments.contains(name) {
            // Visited Style
            config.textProperties.color = .systemGray
            config.image = UIImage(systemName: "checkmark.circle.fill")
            config.imageProperties.tintColor = .systemGreen
            cell.accessoryType = .none
        } else {
            // Pending Style
            config.textProperties.color = .black
            config.image = UIImage(systemName: "circle")
            config.imageProperties.tintColor = .systemBlue
            cell.accessoryType = .disclosureIndicator
        }
        
        cell.contentConfiguration = config
        cell.backgroundColor = .white
        cell.contentView.backgroundColor = .white
        cell.selectionStyle = .none
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let name = assessmentsToDisplay[indexPath.row]
        
        // Mark as visited
        visitedAssessments.insert(name)

        switch name {
        case "ADOS":
            let vc = ADOSAssessmentViewController()
            navigationController?.pushViewController(vc, animated: true)

        case "Birth History":
            let vc = BirthHistoryViewController()
            navigationController?.pushViewController(vc, animated: true)

        case "Patient Difficulties":
            let vc = PatientDifficultiesViewController()
            navigationController?.pushViewController(vc, animated: true)

        case "School Complaints":
            let vc = SchoolComplaintsViewController()
            navigationController?.pushViewController(vc, animated: true)
        case "Medical History":
            let vc = MedicalHistoryViewController()
            navigationController?.pushViewController(vc, animated: true)
        case "Cognitive Skills":
            let vc = CognitiveSkillsViewController()
            navigationController?.pushViewController(vc, animated: true)
        case "Gross Motor Skills":
            let vc = GrossMotorSkillsViewController()
            navigationController?.pushViewController(vc, animated: true)
        case "Fine Motor Skills":
            let vc = FineMotorSkillsViewController()
            navigationController?.pushViewController(vc, animated: true)

        default:
            print("No screen found for \(name)")
        }
    }
    
    // Remove Top Header Space
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNonzeroMagnitude
    }
}
