//
//  noteCardCell.swift
//  OT main
//
//  Created by Garvit Pareek on 12/11/2025.
//

import UIKit

class noteCardCell: UITableViewCell {

    @IBOutlet weak var noteLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
