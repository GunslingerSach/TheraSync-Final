import UIKit

class ProfileViewController: UIViewController {
    
    // MARK: - Data Variables
    var patientData: Patient?
    
    // State variable to track editing mode
    var isEditingMode: Bool = false {
        didSet {
            updateUIForEditState()
        }
    }
    
    // MARK: - UI Elements
    
    let profileImageView: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "person.circle.fill")
        iv.tintColor = .systemGray4
        iv.contentMode = .scaleAspectFill
        iv.backgroundColor = .white
        iv.clipsToBounds = true
        iv.layer.borderColor = UIColor.white.cgColor
        iv.layer.borderWidth = 3.0
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Patient Name"
        label.font = .systemFont(ofSize: 22, weight: .bold)
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    // --- Form Fields ---
    lazy var firstNameField = ProfileViewController.createFormField(placeholder: "First Name")
    lazy var lastNameField = ProfileViewController.createFormField(placeholder: "Last Name")
    
    lazy var genderField = ProfileViewController.createFormField(placeholder: "Gender")
    lazy var bloodGroupField = ProfileViewController.createFormField(placeholder: "Blood Group")
    lazy var addressField = ProfileViewController.createFormField(placeholder: "Address")
    lazy var parentNameField = ProfileViewController.createFormField(placeholder: "Parent's Name")
    
    // This field will remain read-only
    lazy var parentContactField = ProfileViewController.createFormField(placeholder: "Parent Contact")
    
    lazy var referredByField = ProfileViewController.createFormField(placeholder: "Referred By")
    lazy var existingDiagnosisField = ProfileViewController.createFormField(placeholder: "Existing Diagnosis")
    lazy var existingMedicationField = ProfileViewController.createFormField(placeholder: "Existing Medication")
    
    // Date Picker setup
    let dobLabel: UILabel = {
        let label = UILabel()
        label.text = "DOB"
        label.font = .systemFont(ofSize: 16)
        label.textColor = .gray
        return label
    }()
    
    let dobPicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.datePickerMode = .date
        picker.preferredDatePickerStyle = .compact
        picker.isUserInteractionEnabled = false // Read only by default
        return picker
    }()
    
    lazy var dobStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [dobLabel, dobPicker])
        stack.axis = .horizontal
        stack.distribution = .fillProportionally
        stack.heightAnchor.constraint(equalToConstant: 44).isActive = true
        return stack
    }()
    
    // --- Cards ---
    lazy var nameCard: UIView = createCardView(with: [firstNameField, lastNameField])
    lazy var dobCard: UIView = createCardView(with: [dobStack, genderField])
    lazy var contactCard: UIView = createCardView(with: [bloodGroupField, addressField, parentNameField, parentContactField])
    lazy var medicalCard: UIView = createCardView(with: [referredByField, existingDiagnosisField, existingMedicationField])

    // MARK: - View Lifecycle
    
    override func loadView() {
        self.view = GradientView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupHierarchy()
        setupLayout()
        
        populateData()
        
        // Ensure UI starts in the correct state (read-only)
        updateUIForEditState()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        profileImageView.layer.cornerRadius = profileImageView.bounds.width / 2
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    // MARK: - Edit Mode Logic (UPDATED)
    
    func updateUIForEditState() {
        let editableFields: [UITextField] = [
            firstNameField, lastNameField, genderField, bloodGroupField,
            addressField, parentNameField, referredByField,
            existingDiagnosisField, existingMedicationField
        ]
        
        // Update field visuals based on mode
        for field in editableFields {
            field.isUserInteractionEnabled = isEditingMode
            
            // ** FIX: Keep background clear and border none for both states **
            field.backgroundColor = .clear
            field.borderStyle = .none
            
            if isEditingMode {
                // EDIT MODE: Black Text (so user knows they can type)
                field.textColor = .black
            } else {
                // VIEW MODE: Gray Text (Read-only look)
                field.textColor = .systemGray
            }
        }
        
        // DOB Picker logic
        dobPicker.isUserInteractionEnabled = isEditingMode
        dobPicker.alpha = isEditingMode ? 1.0 : 0.6
        
        // Parent Contact ALWAYS read-only
        parentContactField.isUserInteractionEnabled = false
        parentContactField.textColor = .systemGray

        // Update Navigation Bar Button
        if isEditingMode {
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(saveButtonTapped))
            doneButton.tintColor = .white
            navigationItem.rightBarButtonItem = doneButton
        } else {
            setupNavigationBarMenu()
        }
    }
    
    // MARK: - Actions
    
    @objc func backTapped() {
        if let nav = navigationController, nav.viewControllers.first != self {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    
    @objc func saveButtonTapped() {
        print("Saving changes...")
        // Exit edit mode
        isEditingMode = false
    }
    
    // MARK: - Data Population
    
    func populateData() {
        guard let patient = patientData else { return }
        
        nameLabel.text = patient.fullName
        firstNameField.text = patient.firstName
        lastNameField.text = patient.lastName
        dobPicker.date = patient.dateOfBirth
        genderField.text = patient.gender
        bloodGroupField.text = patient.bloodGroup
        addressField.text = patient.address
        parentNameField.text = patient.parentName
        parentContactField.text = patient.parentContact
        referredByField.text = patient.referredBy
        existingDiagnosisField.text = patient.diagnosis
        existingMedicationField.text = patient.medication
    }
    
    // MARK: - Setup Functions
    
    func setupNavigationBarMenu() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(backTapped))
        
        // Menu Actions with Icons
        let notesAction = UIAction(title: "Notes", image: UIImage(systemName: "note.text")) { [weak self] _ in
            let noteVC = NotesViewController()
            noteVC.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(noteVC, animated: true)
        }
        let assessmentAction = UIAction(title: "Assessment", image: UIImage(systemName: "clipboard")) { [weak self] _ in
            let assessmentVC = AssessmentListViewController()
            assessmentVC.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(assessmentVC, animated: true)
        }
        let assignmentAction = UIAction(title: "Assignment", image: UIImage(systemName: "doc.text")) { [weak self] _ in
            let assignmentVC = AssignmentListViewController()
            assignmentVC.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(assignmentVC, animated: true)
        }
        let progressAction = UIAction(title: "Progress", image: UIImage(systemName: "chart.bar")) { _ in print("Progress selected") }
        let editAction = UIAction(title: "Edit", image: UIImage(systemName: "pencil")) { [weak self] _ in
            self?.isEditingMode = true
        }
        let deleteAction = UIAction(title: "Delete", image: UIImage(systemName: "trash"), attributes: .destructive) { _ in }
        
        let mainMenu = UIMenu(title: "", children: [notesAction, assessmentAction, assignmentAction, progressAction, editAction, deleteAction])
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "ellipsis"), menu: mainMenu)
    }
    
    func setupHierarchy() {
        view.addSubview(profileImageView)
        view.addSubview(nameLabel)
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        contentView.addSubview(nameCard)
        contentView.addSubview(dobCard)
        contentView.addSubview(contactCard)
        contentView.addSubview(medicalCard)
    }
    
    func setupLayout() {
        let safeArea = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            profileImageView.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 10),
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 100),
            profileImageView.heightAnchor.constraint(equalToConstant: 100),
            
            nameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 8),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            scrollView.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            contentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            
            nameCard.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            nameCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            nameCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            dobCard.topAnchor.constraint(equalTo: nameCard.bottomAnchor, constant: 16),
            dobCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            dobCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            contactCard.topAnchor.constraint(equalTo: dobCard.bottomAnchor, constant: 16),
            contactCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            contactCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            medicalCard.topAnchor.constraint(equalTo: contactCard.bottomAnchor, constant: 16),
            medicalCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            medicalCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            medicalCard.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40)
        ])
    }
    
    // MARK: - Helpers
    
    static func createFormField(placeholder: String) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.font = .systemFont(ofSize: 16)
        // Default State: Gray text, no border, clear bg
        textField.textColor = .systemGray
        textField.borderStyle = .none
        textField.isUserInteractionEnabled = false
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.heightAnchor.constraint(equalToConstant: 44).isActive = true
        return textField
    }
    
    func createCardView(with fields: [UIView]) -> UIView {
        let card = UIView()
        card.backgroundColor = .white
        card.layer.cornerRadius = 16
        card.clipsToBounds = true
        card.translatesAutoresizingMaskIntoConstraints = false
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 0
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        card.addSubview(stackView)
        
        for (index, field) in fields.enumerated() {
            stackView.addArrangedSubview(field)
            if index < fields.count - 1 {
                let separator = UIView()
                separator.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
                separator.translatesAutoresizingMaskIntoConstraints = false
                separator.heightAnchor.constraint(equalToConstant: 1).isActive = true
                stackView.addArrangedSubview(separator)
            }
        }
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            stackView.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            stackView.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -12)
        ])
        return card
    }
}
