//
//  NewAssignmentViewController.swift
//  NewAssignment
//
//  Created by Alishri Poddar on 27/11/25.
//

import UIKit
import PhotosUI // For Photo/Video Picker
import UniformTypeIdentifiers // For PDF/Document Picker


class NewAssignmentViewController: UIViewController {

    // MARK: - UI Components
    
    // 1. Background (Gradient Header)
    // This stays behind the Navigation Bar to provide the color
    private let headerContainer: GradientView = {
        let view = GradientView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.bottomColor = UIColor(red: 0.95, green: 0.96, blue: 0.98, alpha: 1.0)
        return view
    }()
    
    // 2. Scroll View
    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.showsVerticalScrollIndicator = false
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    // 3. Form Elements
    private let detailsHeaderLabel: UILabel = {
        let label = UILabel()
        label.text = "Assignment Details"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = .black
        return label
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Title"
        label.font = .systemFont(ofSize: 16, weight: .bold)
        label.textColor = .black
        return label
    }()
    
    private let titleTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Assignment Title"
        tf.backgroundColor = .white
        tf.layer.cornerRadius = 25
        tf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 16, height: 50))
        tf.leftViewMode = .always
        tf.heightAnchor.constraint(equalToConstant: 50).isActive = true
        return tf
    }()
    
    private let instructionLabel: UILabel = {
        let label = UILabel()
        label.text = "Instruction"
        label.font = .systemFont(ofSize: 16, weight: .bold)
        label.textColor = .black
        return label
    }()
    
    private let instructionTextView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 16)
        tv.backgroundColor = .white
        tv.layer.cornerRadius = 25
        tv.textContainerInset = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        tv.text = "Assignment Instruction"
        tv.textColor = .lightGray
        tv.heightAnchor.constraint(equalToConstant: 120).isActive = true
        return tv
    }()
    
    // Date Picker Section
    private let dateContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 25
        view.translatesAutoresizingMaskIntoConstraints = false
        view.heightAnchor.constraint(equalToConstant: 55).isActive = true
        return view
    }()
    
    private let dateLabel: UILabel = {
        let label = UILabel()
        label.text = "Select Due Date"
        label.textColor = .lightGray
        label.font = .systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let datePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.datePickerMode = .date
        picker.preferredDatePickerStyle = .compact
        picker.tintColor = .systemBlue
        picker.translatesAutoresizingMaskIntoConstraints = false
        return picker
    }()
    
    // Assignment Type Picker Section
    private let typeContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 25
        view.translatesAutoresizingMaskIntoConstraints = false
        view.heightAnchor.constraint(equalToConstant: 55).isActive = true
        return view
    }()
    
    private let typeTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Select Type"
        tf.text = "Select Type"
        tf.textColor = .lightGray
        tf.tintColor = .clear // Hide cursor
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    private let chevronIcon: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "chevron.right")
        iv.tintColor = .lightGray
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let typePicker = UIPickerView()
    private let typeOptions = ["Quiz", "Video Submission"]
    
    // Attachments Button
    private let attachmentButton: UIButton = {
        var config = UIButton.Configuration.filled()
        config.baseBackgroundColor = .white
        config.baseForegroundColor = .systemBlue
        config.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16)
        config.cornerStyle = .medium
        config.image = UIImage(systemName: "paperclip")
        config.imagePadding = 10
        config.title = "Attachments"
        config.background.cornerRadius = 25
        
        let btn = UIButton(configuration: config)
        btn.contentHorizontalAlignment = .leading
        btn.heightAnchor.constraint(equalToConstant: 50).isActive = true
        return btn
    }()

    private let nextButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Next", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = .systemBlue
        btn.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.heightAnchor.constraint(equalToConstant: 55).isActive = true
        return btn
    }()
    
    private let mainStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 15
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.95, green: 0.96, blue: 0.98, alpha: 1.0)
        
        setupNavBar()
        setupLayout()
        setupPickers()
        setupInteractions()
        
        // Tap to dismiss keyboard
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    // MARK: - Setup Logic
    
    private func setupNavBar() {
        // 1. Set the Title
        self.title = "New Assignment"
        
        // 2. Configure Appearance
        let appearance = UINavigationBarAppearance()
        // Make it transparent so the GradientView behind it shows through
        appearance.configureWithTransparentBackground()
        // Set the Title Color to White
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        // 3. Apply settings
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        
        // 4. Set Tint Color (for back arrow) to White
        navigationController?.navigationBar.tintColor = .white
    }
    
    private func setupPickers() {
        typePicker.delegate = self
        typePicker.dataSource = self
        typeTextField.inputView = typePicker
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(dismissKeyboard))
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexSpace, doneBtn], animated: true)
        typeTextField.inputAccessoryView = toolbar
    }
    
    private func setupInteractions() {
        typeContainerView.isUserInteractionEnabled = true
        let containerTap = UITapGestureRecognizer(target: self, action: #selector(openTypePicker))
        typeContainerView.addGestureRecognizer(containerTap)
        
        chevronIcon.isUserInteractionEnabled = true
        let chevronTap = UITapGestureRecognizer(target: self, action: #selector(openTypePicker))
        chevronIcon.addGestureRecognizer(chevronTap)
        
        attachmentButton.addTarget(self, action: #selector(didTapAttachments), for: .touchUpInside)
    }
    
    private func setupLayout() {
        view.addSubview(headerContainer)
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        dateContainerView.addSubview(dateLabel)
        dateContainerView.addSubview(datePicker)
        
        typeContainerView.addSubview(typeTextField)
        typeContainerView.addSubview(chevronIcon)
        
        contentView.addSubview(mainStack)
        
        mainStack.addArrangedSubview(detailsHeaderLabel)
        mainStack.setCustomSpacing(20, after: detailsHeaderLabel)
        mainStack.addArrangedSubview(titleLabel)
        mainStack.addArrangedSubview(titleTextField)
        mainStack.addArrangedSubview(instructionLabel)
        mainStack.addArrangedSubview(instructionTextView)
        
        let spacerView = UIView()
        spacerView.heightAnchor.constraint(equalToConstant: 10).isActive = true
        mainStack.addArrangedSubview(spacerView)
        
        mainStack.addArrangedSubview(dateContainerView)
        mainStack.addArrangedSubview(typeContainerView)
        
        let attachmentSpacer = UIView()
        attachmentSpacer.heightAnchor.constraint(equalToConstant: 10).isActive = true
        mainStack.addArrangedSubview(attachmentSpacer)
        
        let attachContainer = UIView()
        attachContainer.addSubview(attachmentButton)
        attachmentButton.translatesAutoresizingMaskIntoConstraints = false
        attachmentButton.leadingAnchor.constraint(equalTo: attachContainer.leadingAnchor).isActive = true
        attachmentButton.topAnchor.constraint(equalTo: attachContainer.topAnchor).isActive = true
        attachmentButton.bottomAnchor.constraint(equalTo: attachContainer.bottomAnchor).isActive = true
        
        mainStack.addArrangedSubview(attachContainer)
        
        view.addSubview(nextButton)
        
        NSLayoutConstraint.activate([
            // Header Gradient Background (Stays pinned to top)
            headerContainer.topAnchor.constraint(equalTo: view.topAnchor),
            headerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerContainer.heightAnchor.constraint(equalToConstant: 250),
            
            // Scroll View - Starts below Safe Area (so it's under the Nav Bar)
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: nextButton.topAnchor, constant: -20),
            
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            mainStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            mainStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            mainStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            mainStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),
            
            dateLabel.leadingAnchor.constraint(equalTo: dateContainerView.leadingAnchor, constant: 16),
            dateLabel.centerYAnchor.constraint(equalTo: dateContainerView.centerYAnchor),
            
            datePicker.trailingAnchor.constraint(equalTo: dateContainerView.trailingAnchor, constant: -16),
            datePicker.centerYAnchor.constraint(equalTo: dateContainerView.centerYAnchor),
            
            typeTextField.leadingAnchor.constraint(equalTo: typeContainerView.leadingAnchor, constant: 16),
            typeTextField.trailingAnchor.constraint(equalTo: chevronIcon.leadingAnchor, constant: -10),
            typeTextField.topAnchor.constraint(equalTo: typeContainerView.topAnchor),
            typeTextField.bottomAnchor.constraint(equalTo: typeContainerView.bottomAnchor),
            
            chevronIcon.trailingAnchor.constraint(equalTo: typeContainerView.trailingAnchor, constant: -16),
            chevronIcon.centerYAnchor.constraint(equalTo: typeContainerView.centerYAnchor),
            chevronIcon.widthAnchor.constraint(equalToConstant: 12),
            chevronIcon.heightAnchor.constraint(equalToConstant: 20),
            
            nextButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10)
        ])
    }
    
    // MARK: - User Actions
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc private func openTypePicker() {
        typeTextField.becomeFirstResponder()
    }
    
    @objc private func didTapAttachments() {
        let alert = UIAlertController(title: "Add Attachment", message: "Choose file type", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Photo or Video", style: .default, handler: { _ in
            self.showPhotoPicker()
        }))
        
        alert.addAction(UIAlertAction(title: "Document (PDF)", style: .default, handler: { _ in
            self.showDocumentPicker()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        // iPad crash fix
        if let popover = alert.popoverPresentationController {
            popover.sourceView = self.attachmentButton
            popover.sourceRect = self.attachmentButton.bounds
        }
        
        present(alert, animated: true)
    }
    
    private func showPhotoPicker() {
        var config = PHPickerConfiguration()
        config.selectionLimit = 0
        config.filter = .any(of: [.images, .videos])
        
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        present(picker, animated: true)
    }
    
    private func showDocumentPicker() {
        let supportedTypes: [UTType] = [.pdf, .text, .image]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes)
        picker.delegate = self
        picker.allowsMultipleSelection = true
        present(picker, animated: true)
    }
}

// MARK: - Picker Delegate
extension NewAssignmentViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int { return 1 }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return typeOptions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typeOptions[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        typeTextField.text = typeOptions[row]
        typeTextField.textColor = .black
    }
}

// MARK: - PHPickerViewControllerDelegate
extension NewAssignmentViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        if !results.isEmpty {
            print("User selected \(results.count) photos/videos.")
        }
    }
}

// MARK: - UIDocumentPickerDelegate
extension NewAssignmentViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if !urls.isEmpty {
            print("User selected documents: \(urls)")
        }
    }
}
