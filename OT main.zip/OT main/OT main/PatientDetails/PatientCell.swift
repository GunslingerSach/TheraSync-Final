import UIKit

final class PatientCell: UITableViewCell {

    static let reuseId = "PatientCell"

    // Avatar (circular)
    private let avatarImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    // Name label (bold)
    private let nameLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
        l.textColor = .black
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    // Subtitle label (gender & age)
    private let detailLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        l.textColor = UIColor(white: 0.45, alpha: 1.0)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    // Divider line
    private let divider: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0.92, alpha: 1.0)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
        selectionStyle = .none
        backgroundColor = .white

        // default accessory to match screenshot (chevron)
        accessoryType = .disclosureIndicator
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
        setupConstraints()
    }

    // MARK: - Setup

    private func setupViews() {
        contentView.addSubview(avatarImageView)
        contentView.addSubview(nameLabel)
        contentView.addSubview(detailLabel)
        contentView.addSubview(divider)
    }

    private func setupConstraints() {
        // Avatar size 48x48 (rounded)
        NSLayoutConstraint.activate([
            avatarImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            avatarImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            avatarImageView.widthAnchor.constraint(equalToConstant: 48),
            avatarImageView.heightAnchor.constraint(equalToConstant: 48),

            nameLabel.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 14),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -44),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 14),

            detailLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            detailLabel.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -44),
            detailLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 6),

            divider.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),
            divider.heightAnchor.constraint(equalToConstant: 1.0),
            divider.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        // circular avatar
        avatarImageView.layer.cornerRadius = avatarImageView.bounds.width / 2
    }

    // MARK: - Configure

    /// Configure the cell with the app's `Patient` model.
    func configure(with patient: Patient) {
        nameLabel.text = patient.fullName

        // compute approximate age from DOB
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: patient.dateOfBirth, to: Date())
        let age = ageComponents.year ?? 0

        detailLabel.text = "Gender: \(patient.gender)   Age: \(age)"

        if let img = patient.image {
            avatarImageView.image = img
        } else {
            // fallback avatar (circular)
            if #available(iOS 13.0, *) {
                avatarImageView.image = UIImage(systemName: "person.crop.circle.fill")
            } else {
                avatarImageView.image = UIImage()
            }
            avatarImageView.tintColor = .darkGray
            avatarImageView.backgroundColor = .clear
        }

        // default: show divider (caller can override with showDivider)
        divider.isHidden = false
    }

    /// Convenience configure if you want to pass raw values (optional)
    func configure(name: String, gender: String, age: Int, image: UIImage?) {
        nameLabel.text = name
        detailLabel.text = "Gender: \(gender)   Age: \(age)"
        if let img = image { avatarImageView.image = img }
        else {
            if #available(iOS 13.0, *) {
                avatarImageView.image = UIImage(systemName: "person.crop.circle.fill")
            } else {
                avatarImageView.image = UIImage()
            }
            avatarImageView.tintColor = .darkGray
            avatarImageView.backgroundColor = .clear
        }
        divider.isHidden = false
    }

    // MARK: - Divider control

    /// Call `cell.showDivider(false)` for the last cell so there's no trailing line.
    func showDivider(_ show: Bool) {
        divider.isHidden = !show
    }
}
