import UIKit
struct Patient {
    var firstName: String
    var lastName: String
    var gender: String
    var dateOfBirth: Date
    var bloodGroup: String
    var address: String
    var parentName: String
    var parentContact: String
    var referredBy: String
    var diagnosis: String
    var medication: String
    var image: UIImage?

    // convenience
    var fullName: String { "\(firstName) \(lastName)" }

    // computed age (useful in cells)
    var age: Int {
        Calendar.current.dateComponents([.year], from: dateOfBirth, to: Date()).year ?? 0
    }
}
class PatientListViewController: UIViewController {
    // Header elements (same styling as before)
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Patients"
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 36, weight: .bold)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // Top-right small plus (hidden when no patients)
    private let navPlusButton: UIButton = {
        let button = UIButton(type: .system)
        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)
        let img = UIImage(systemName: "plus", withConfiguration: config)
        button.setImage(img, for: .normal)
        button.tintColor = .white
        button.backgroundColor = UIColor(red: 0.11, green: 0.45, blue: 0.98, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 24
        button.layer.borderWidth = 1.5
        button.layer.borderColor = UIColor(white: 1.0, alpha: 0.35).cgColor
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.28
        button.layer.shadowOffset = CGSize(width: 0, height: 4)
        button.layer.shadowRadius = 6
        button.accessibilityLabel = "Add patient"
        return button
    }()

    // Search field (hidden when no patients)
    private let searchField: UITextField = {
        let tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Search"
        tf.font = UIFont.systemFont(ofSize: 16)
        tf.textColor = .white
        tf.clearButtonMode = .whileEditing
        tf.returnKeyType = .search
        tf.backgroundColor = UIColor(white: 1.0, alpha: 0.10)
        tf.layer.cornerRadius = 22
        tf.clipsToBounds = true

        let iv = UIImageView(image: UIImage(systemName: "magnifyingglass"))
        iv.tintColor = UIColor(white: 1.0, alpha: 0.85)
        iv.contentMode = .scaleAspectFit
        iv.frame = CGRect(x: 0, y: 0, width: 36, height: 36)

        let container = UIView(frame: CGRect(x: 0, y: 0, width: 52, height: 44))
        iv.center = CGPoint(x: container.bounds.midX - 6, y: container.bounds.midY)
        container.addSubview(iv)
        tf.leftView = container
        tf.leftViewMode = .always

        tf.attributedPlaceholder = NSAttributedString(
            string: "Search",
            attributes: [.foregroundColor: UIColor(white: 1.0, alpha: 0.72),
                         .font: UIFont.systemFont(ofSize: 16)]
        )
        tf.accessibilityLabel = "Search patients"
        return tf
    }()

    // Card + table (same approach)
    private let cardShadowContainer: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.shadowColor = UIColor.black.cgColor
        v.layer.shadowOpacity = 0.12
        v.layer.shadowRadius = 12
        v.layer.shadowOffset = CGSize(width: 0, height: 6)
        v.backgroundColor = .clear
        return v
    }()

    private let cardContentView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 20
        v.layer.masksToBounds = true
        return v
    }()

    private let tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.separatorInset = UIEdgeInsets(top: 0, left: 84, bottom: 0, right: 0)
        tv.tableFooterView = UIView()
        tv.backgroundColor = .white
        return tv
    }()

    // Empty state (centered plus + label) shown when patients.isEmpty
    private let emptyCenterPlusButton: UIButton = {
        let b = UIButton(type: .system)
        let conf = UIImage.SymbolConfiguration(pointSize: 28, weight: .bold)
        b.setImage(UIImage(systemName: "plus", withConfiguration: conf), for: .normal)
        b.tintColor = .white
        b.backgroundColor = UIColor(red: 0.11, green: 0.45, blue: 0.98, alpha: 1.0)
        b.layer.cornerRadius = 36
        b.translatesAutoresizingMaskIntoConstraints = false
        b.layer.shadowColor = UIColor.black.cgColor
        b.layer.shadowOpacity = 0.25
        b.layer.shadowOffset = CGSize(width: 0, height: 6)
        b.layer.shadowRadius = 8
        return b
    }()

    private let emptyCenterLabel: UILabel = {
        let l = UILabel()
        l.text = "Add patients to see details"
        l.textColor = .white
        l.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    // Data source
    private var patients: [Patient] = [] {
        didSet {
            // ensure allPatients only when non-empty (preserve empty-state restore)
            if !patients.isEmpty { allPatients = patients }
            updateUIForDataState()
            updateCardHeightIfNeeded()
        }
    }

    // Backup full array for search
    private var allPatients: [Patient] = []

    // Row & layout constants
    private let rowHeight: CGFloat = 76
    private let tableTopPadding: CGFloat = 10
    private let tableBottomPadding: CGFloat = 8
    private let reservedTabBarHeight: CGFloat = 100 // space to leave for tabbar area (adjustable)

    // Constraint we will update to resize the card
    private var cardHeightConstraint: NSLayoutConstraint?

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBackground
        navigationController?.setNavigationBarHidden(true, animated: false)

        setupGradientBackground()
        setupHeaderAndSearch()
        setupCardAndTable()
        setupEmptyState()

        // Table
        tableView.register(PatientCell.self, forCellReuseIdentifier: PatientCell.reuseId)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = rowHeight
        tableView.estimatedRowHeight = rowHeight
        tableView.separatorStyle = .none              // disable system separators
        // Hooks
        navPlusButton.addTarget(self, action: #selector(handleNavPlus), for: .touchUpInside)
        emptyCenterPlusButton.addTarget(self, action: #selector(handleNavPlus), for: .touchUpInside)
        searchField.addTarget(self, action: #selector(searchFieldChanged(_:)), for: .editingChanged)

        // initial UI state
        updateUIForDataState()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Avoid layout jump when coming back from other VCs
        navigationController?.setNavigationBarHidden(true, animated: false)
        view.setNeedsLayout()
        view.layoutIfNeeded()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Recalculate card height once layout is available
        updateCardHeightIfNeeded()
    }

    // MARK: - Background
    private func setupGradientBackground() {
        let gradientView = GradientView(frame: view.bounds)
        gradientView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(gradientView)
        view.sendSubviewToBack(gradientView)
        NSLayoutConstraint.activate([
            gradientView.topAnchor.constraint(equalTo: view.topAnchor),
            gradientView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gradientView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: - Header & Search
    private func setupHeaderAndSearch() {
        view.addSubview(titleLabel)
        view.addSubview(navPlusButton)
        view.addSubview(searchField)

        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),

            navPlusButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            navPlusButton.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor, constant: 4),
            navPlusButton.widthAnchor.constraint(equalToConstant: 48),
            navPlusButton.heightAnchor.constraint(equalToConstant: 48),

            searchField.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 18),
            searchField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            searchField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            searchField.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    // MARK: - Card & Table layout (we create a height constraint we will update)
    private func setupCardAndTable() {
        view.addSubview(cardShadowContainer)
        cardShadowContainer.addSubview(cardContentView)
        cardContentView.addSubview(tableView)

        // create the height constraint (initial reasonable constant)
        cardHeightConstraint = cardShadowContainer.heightAnchor.constraint(equalToConstant: 300)
        cardHeightConstraint?.isActive = true

        NSLayoutConstraint.activate([
            cardShadowContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cardShadowContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            cardShadowContainer.topAnchor.constraint(equalTo: searchField.bottomAnchor, constant: 20),

            cardContentView.topAnchor.constraint(equalTo: cardShadowContainer.topAnchor),
            cardContentView.leadingAnchor.constraint(equalTo: cardShadowContainer.leadingAnchor),
            cardContentView.trailingAnchor.constraint(equalTo: cardShadowContainer.trailingAnchor),
            cardContentView.bottomAnchor.constraint(equalTo: cardShadowContainer.bottomAnchor),

            tableView.topAnchor.constraint(equalTo: cardContentView.topAnchor, constant: tableTopPadding),
            tableView.leadingAnchor.constraint(equalTo: cardContentView.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: cardContentView.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: cardContentView.bottomAnchor, constant: -tableBottomPadding)
        ])
    }

    // MARK: - Empty State
    private func setupEmptyState() {
        view.addSubview(emptyCenterPlusButton)
        view.addSubview(emptyCenterLabel)

        NSLayoutConstraint.activate([
            emptyCenterPlusButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyCenterPlusButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -20),
            emptyCenterPlusButton.widthAnchor.constraint(equalToConstant: 72),
            emptyCenterPlusButton.heightAnchor.constraint(equalToConstant: 72),

            emptyCenterLabel.topAnchor.constraint(equalTo: emptyCenterPlusButton.bottomAnchor, constant: 12),
            emptyCenterLabel.centerXAnchor.constraint(equalTo: emptyCenterPlusButton.centerXAnchor)
        ])
    }

    // MARK: - UI State update
    private func updateUIForDataState() {
        let hasPatients = !patients.isEmpty

        navPlusButton.isHidden = !hasPatients
        searchField.isHidden = !hasPatients
        cardShadowContainer.isHidden = !hasPatients
        tableView.isHidden = !hasPatients

        emptyCenterPlusButton.isHidden = hasPatients
        emptyCenterLabel.isHidden = hasPatients

        if hasPatients {
            tableView.reloadData()
            // compute height now
            updateCardHeightIfNeeded()
        }
    }

    // MARK: - Dynamic sizing logic
    private func updateCardHeightIfNeeded() {
        guard let cardHeightConstraint = cardHeightConstraint else { return }

        // If no patients, collapse the card
        guard !patients.isEmpty else {
            cardHeightConstraint.constant = 0
            return
        }

        // 1) content height required for rows
        let contentHeight = CGFloat(patients.count) * rowHeight

        // 2) add vertical paddings inside card
        let totalHeightNeeded = contentHeight + tableTopPadding + tableBottomPadding

        // 3) compute maximum allowed height so card won't overlap reserved tab area
        let topOfCardY = searchField.frame.maxY + 20 // same spacing as constraints
        let safeAreaBottomInset = view.safeAreaInsets.bottom
        let maxAllowedHeight = max(96, view.bounds.height - topOfCardY - reservedTabBarHeight - safeAreaBottomInset)

        // 4) final height: if content fits, use exact content size; otherwise clamp to maxAllowedHeight
        let finalHeight: CGFloat
        if totalHeightNeeded <= maxAllowedHeight {
            // content fits — use exact needed height
            finalHeight = totalHeightNeeded
            tableView.isScrollEnabled = false
        } else {
            // content larger than available — use max and allow scrolling
            finalHeight = maxAllowedHeight
            tableView.isScrollEnabled = true
        }

        // 5) apply with a small animation
        UIView.animate(withDuration: 0.16) {
            cardHeightConstraint.constant = finalHeight
            self.view.layoutIfNeeded()
        }
    }


    // MARK: - Actions
    @objc private func handleNavPlus() {
        let addVC = addPatient(nibName: "addPatient", bundle: nil)
        addVC.delegate = self
        let nav = UINavigationController(rootViewController: addVC)
        nav.modalPresentationStyle = .formSheet
        present(nav, animated: true, completion: nil)
    }

    @objc private func searchFieldChanged(_ tf: UITextField) {
        let q = tf.text?.lowercased() ?? ""
        if q.isEmpty {
            patients = allPatients
        } else {
            patients = allPatients.filter { $0.fullName.lowercased().contains(q) }
        }
        tableView.reloadData()
        updateCardHeightIfNeeded()
    }
}

// MARK: - Table datasource/delegate + navigation to ProfileViewController
extension PatientListViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        patients.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PatientCell.reuseId, for: indexPath) as? PatientCell else {
            return UITableViewCell()
        }

        let patient = patients[indexPath.row]

        // configure first
        cell.configure(with: patient)

        // then hide divider for last row
        let isLast = indexPath.row == patients.count - 1
        cell.showDivider(!isLast)

        return cell
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let patient = patients[indexPath.row]
        let profileVC = ProfileViewController()
        profileVC.patientData = patient
        profileVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(profileVC, animated: true)
    }
}

// Adapter — reuses same Patient struct for cell config (keeps full model)
private func PatientForCell(from patient: Patient) -> Patient {
    return patient
}

// MARK: - AddPatientDelegate
extension PatientListViewController: AddPatientDelegate {
    func didAddPatient(_ patient: Patient) {
        // Append, update search backup and UI
        patients.append(patient)
        allPatients = patients
        // UI updates and height recalculation happen in didSet
    }
}
