import UIKit

class AppointmentTableViewCell: UITableViewCell {

    static let reuseId = "AppointmentCell"

    private let timeLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.font = .systemFont(ofSize: 20, weight: .bold)
        l.textColor = .black
        return l
    }()

    private let titleLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.font = .systemFont(ofSize: 16, weight: .semibold)
        l.textColor = .black
        return l
    }()

    private let dateLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.font = .systemFont(ofSize: 12, weight: .regular)
        l.textColor = UIColor.systemGray
        return l
    }()

    private let container: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .clear
        return v
    }()

    private let separator: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0.92, alpha: 1.0)
        return v
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .clear

        contentView.addSubview(container)
        container.addSubview(timeLabel)
        container.addSubview(titleLabel)
        container.addSubview(dateLabel)
        contentView.addSubview(separator)

        NSLayoutConstraint.activate([
            container.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0),
            container.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            container.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            container.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),

            timeLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 12),
            timeLabel.widthAnchor.constraint(equalToConstant: 120),
            timeLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),

            // Moved Title up slightly (from 22 to 14) to fit smaller cell height
            titleLabel.leadingAnchor.constraint(equalTo: timeLabel.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
            titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 14),

            // Moved Date closer to Title
            dateLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            dateLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),

            separator.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0),
            separator.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            separator.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            separator.heightAnchor.constraint(equalToConstant: 1)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }

    func configure(time: String, title: String, date: String) {
        timeLabel.text = time
        titleLabel.text = title
        dateLabel.text = date
    }
}
