//
//  AddReminderViewController.swift
//  Trial
//
//  Created by user@54 on 14/11/25.
//

import UIKit

protocol AddReminderDelegate: AnyObject {
    func didAddAppointment(title: String, subtitle: String, date: Date, time: Date)
}

class AddReminderViewController: UIViewController {

    weak var delegate: AddReminderDelegate?

    private var selectedDate: Date = Date()
    private var selectedTime: Date = Date()
    private var activeMode: UIDatePicker.Mode = .time

    // UI
    private let grabber: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0.85, alpha: 1.0)
        v.layer.cornerRadius = 2.5
        return v
    }()

    private let closeButton: UIButton = {
        let b = UIButton(type:.system); b.translatesAutoresizingMaskIntoConstraints = false
        b.setImage(UIImage(systemName: "xmark"), for: .normal)
        b.tintColor = UIColor(white: 0.18, alpha: 1.0)
        return b
    }()

    private let doneButton: UIButton = {
        let b = UIButton(type:.system); b.translatesAutoresizingMaskIntoConstraints = false
        b.setImage(UIImage(systemName: "checkmark"), for: .normal)
        b.tintColor = .white
        b.backgroundColor = UIColor(red: 74/255, green: 137/255, blue: 255/255, alpha: 1.0)
        b.layer.cornerRadius = 22
        b.layer.masksToBounds = false
        b.layer.shadowColor = UIColor.black.cgColor
        b.layer.shadowOpacity = 0.12
        b.layer.shadowRadius = 6
        b.layer.shadowOffset = CGSize(width: 0, height: 3)
        return b
    }()

    private let headerLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Add Appointment"
        l.font = .systemFont(ofSize: 18, weight: .semibold)
        l.textAlignment = .center
        l.textColor = .black
        return l
    }()

    private let titleRounded: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 14
        v.layer.masksToBounds = true
        return v
    }()

    private let titleTextField: UITextField = {
        let t = UITextField(); t.translatesAutoresizingMaskIntoConstraints = false
        t.placeholder = "Title"
        t.font = .systemFont(ofSize: 18, weight: .regular)
        return t
    }()

    private let sectionLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Date & Time"
        l.font = .systemFont(ofSize: 14, weight: .regular)
        l.textColor = UIColor(white: 0.45, alpha: 1.0)
        return l
    }()

    private let dateRow: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0.98, alpha: 1.0)
        v.layer.cornerRadius = 12
        v.layer.masksToBounds = true
        return v
    }()
    private let dateIcon: UIImageView = {
        let iv = UIImageView(image: UIImage(systemName: "calendar")); iv.translatesAutoresizingMaskIntoConstraints = false
        iv.tintColor = UIColor(white: 0.2, alpha: 1.0); return iv
    }()
    private let dateLeftLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Date"; l.font = .systemFont(ofSize: 16, weight: .regular); return l
    }()
    private let dateRightLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "June 2024"; l.font = .systemFont(ofSize: 15, weight: .regular); l.textColor = UIColor(white: 0.18, alpha: 1.0); l.textAlignment = .right
        return l
    }()

    private let timeRow: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0.98, alpha: 1.0)
        v.layer.cornerRadius = 12
        v.layer.masksToBounds = true
        return v
    }()
    private let timeIcon: UIImageView = {
        let iv = UIImageView(image: UIImage(systemName: "clock")); iv.translatesAutoresizingMaskIntoConstraints = false
        iv.tintColor = UIColor(white: 0.2, alpha: 1.0); return iv
    }()
    private let timeLeftLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Time"; l.font = .systemFont(ofSize: 16, weight: .regular); return l
    }()
    private let timeRightLabel: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "8:00 AM"; l.font = .systemFont(ofSize: 15, weight: .regular); l.textColor = UIColor(white: 0.18, alpha: 1.0); l.textAlignment = .right
        return l
    }()

    private let pickerContainer: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false; v.backgroundColor = .clear
        return v
    }()
    private let datePicker: UIDatePicker = {
        let d = UIDatePicker(); d.translatesAutoresizingMaskIntoConstraints = false
        d.preferredDatePickerStyle = .wheels
        d.date = Date()
        return d
    }()

    // MARK: - lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.systemGray6

        buildHierarchy()
        setupConstraints()
        configureActions()
        updateLabels()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let sheet = sheetPresentationController {
            sheet.detents = [.medium(), .large()]
            sheet.prefersGrabberVisible = true
            sheet.preferredCornerRadius = 20
        }
    }

    private func buildHierarchy() {
        view.addSubview(grabber)
        view.addSubview(closeButton)
        view.addSubview(doneButton)
        view.addSubview(headerLabel)

        view.addSubview(titleRounded)
        titleRounded.addSubview(titleTextField)

        view.addSubview(sectionLabel)

        view.addSubview(dateRow)
        dateRow.addSubview(dateIcon)
        dateRow.addSubview(dateLeftLabel)
        dateRow.addSubview(dateRightLabel)

        view.addSubview(timeRow)
        timeRow.addSubview(timeIcon)
        timeRow.addSubview(timeLeftLabel)
        timeRow.addSubview(timeRightLabel)

        view.addSubview(pickerContainer)
        pickerContainer.addSubview(datePicker)
    }

    private func setupConstraints() {
        let safe = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            grabber.topAnchor.constraint(equalTo: view.topAnchor, constant: 8),
            grabber.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            grabber.widthAnchor.constraint(equalToConstant: 60),
            grabber.heightAnchor.constraint(equalToConstant: 5),

            closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            closeButton.centerYAnchor.constraint(equalTo: grabber.centerYAnchor, constant: 24),
            closeButton.widthAnchor.constraint(equalToConstant: 36),
            closeButton.heightAnchor.constraint(equalToConstant: 36),

            doneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            doneButton.centerYAnchor.constraint(equalTo: closeButton.centerYAnchor),
            doneButton.widthAnchor.constraint(equalToConstant: 44),
            doneButton.heightAnchor.constraint(equalToConstant: 44),

            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            headerLabel.centerYAnchor.constraint(equalTo: closeButton.centerYAnchor),

            titleRounded.topAnchor.constraint(equalTo: closeButton.bottomAnchor, constant: 14),
            titleRounded.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleRounded.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            titleRounded.heightAnchor.constraint(equalToConstant: 86),

            titleTextField.leadingAnchor.constraint(equalTo: titleRounded.leadingAnchor, constant: 18),
            titleTextField.trailingAnchor.constraint(equalTo: titleRounded.trailingAnchor, constant: -18),
            titleTextField.centerYAnchor.constraint(equalTo: titleRounded.centerYAnchor),
            titleTextField.heightAnchor.constraint(equalToConstant: 48),

            sectionLabel.topAnchor.constraint(equalTo: titleRounded.bottomAnchor, constant: 18),
            sectionLabel.leadingAnchor.constraint(equalTo: titleRounded.leadingAnchor),

            dateRow.topAnchor.constraint(equalTo: sectionLabel.bottomAnchor, constant: 12),
            dateRow.leadingAnchor.constraint(equalTo: titleRounded.leadingAnchor),
            dateRow.trailingAnchor.constraint(equalTo: titleRounded.trailingAnchor),
            dateRow.heightAnchor.constraint(equalToConstant: 56),

            dateIcon.leadingAnchor.constraint(equalTo: dateRow.leadingAnchor, constant: 12),
            dateIcon.centerYAnchor.constraint(equalTo: dateRow.centerYAnchor),
            dateIcon.widthAnchor.constraint(equalToConstant: 24),
            dateIcon.heightAnchor.constraint(equalToConstant: 24),

            dateLeftLabel.leadingAnchor.constraint(equalTo: dateIcon.trailingAnchor, constant: 12),
            dateLeftLabel.centerYAnchor.constraint(equalTo: dateRow.centerYAnchor),

            dateRightLabel.trailingAnchor.constraint(equalTo: dateRow.trailingAnchor, constant: -12),
            dateRightLabel.centerYAnchor.constraint(equalTo: dateRow.centerYAnchor),
            dateRightLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 80),

            timeRow.topAnchor.constraint(equalTo: dateRow.bottomAnchor, constant: 12),
            timeRow.leadingAnchor.constraint(equalTo: titleRounded.leadingAnchor),
            timeRow.trailingAnchor.constraint(equalTo: titleRounded.trailingAnchor),
            timeRow.heightAnchor.constraint(equalToConstant: 56),

            timeIcon.leadingAnchor.constraint(equalTo: timeRow.leadingAnchor, constant: 12),
            timeIcon.centerYAnchor.constraint(equalTo: timeRow.centerYAnchor),
            timeIcon.widthAnchor.constraint(equalToConstant: 24),
            timeIcon.heightAnchor.constraint(equalToConstant: 24),

            timeLeftLabel.leadingAnchor.constraint(equalTo: timeIcon.trailingAnchor, constant: 12),
            timeLeftLabel.centerYAnchor.constraint(equalTo: timeRow.centerYAnchor),

            timeRightLabel.trailingAnchor.constraint(equalTo: timeRow.trailingAnchor, constant: -12),
            timeRightLabel.centerYAnchor.constraint(equalTo: timeRow.centerYAnchor),
            timeRightLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 80),

            pickerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pickerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pickerContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            pickerContainer.heightAnchor.constraint(equalToConstant: 240),

            datePicker.leadingAnchor.constraint(equalTo: pickerContainer.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: pickerContainer.trailingAnchor),
            datePicker.topAnchor.constraint(equalTo: pickerContainer.topAnchor),
            datePicker.bottomAnchor.constraint(equalTo: pickerContainer.bottomAnchor)
        ])
    }

    private func configureActions() {
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        doneButton.addTarget(self, action: #selector(doneTapped), for: .touchUpInside)

        let dTap = UITapGestureRecognizer(target: self, action: #selector(dateRowTapped))
        dateRow.addGestureRecognizer(dTap)
        let tTap = UITapGestureRecognizer(target: self, action: #selector(timeRowTapped))
        timeRow.addGestureRecognizer(tTap)

        datePicker.addTarget(self, action: #selector(pickerChanged(_:)), for: .valueChanged)

        titleTextField.delegate = self
        // initial mode = date so wheel has day+month+year as screenshot
        activeMode = .date
        datePicker.datePickerMode = .date
        datePicker.date = selectedDate
    }

    // MARK: - actions

    @objc private func closeTapped() { dismiss(animated: true) }

    @objc private func doneTapped() {
        let title = titleTextField.text ?? "Untitled"
        delegate?.didAddAppointment(title: title, subtitle: "", date: selectedDate, time: selectedTime)
        dismiss(animated: true)
    }

    @objc private func dateRowTapped() {
        activeMode = .date
        datePicker.datePickerMode = .date
        datePicker.date = selectedDate
    }

    @objc private func timeRowTapped() {
        activeMode = .time
        datePicker.datePickerMode = .time
        datePicker.date = selectedTime
    }

    @objc private func pickerChanged(_ sender: UIDatePicker) {
        if activeMode == .date {
            selectedDate = sender.date
        } else {
            selectedTime = sender.date
        }
        updateLabels()
    }

    private func updateLabels() {
        let monthFmt = DateFormatter(); monthFmt.dateFormat = "LLLL yyyy"
        dateRightLabel.text = monthFmt.string(from: selectedDate)

        let timeFmt = DateFormatter(); timeFmt.dateFormat = "h:mm a"
        timeRightLabel.text = timeFmt.string(from: selectedTime)
    }
}

// MARK: - UITextFieldDelegate
extension AddReminderViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder(); return true
    }
}
