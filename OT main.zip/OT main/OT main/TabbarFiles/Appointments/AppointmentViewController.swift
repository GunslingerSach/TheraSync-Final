import UIKit

// Make sure OTCalendarView.swift, AddReminderViewController.swift, and GradientView.swift exist.

class AppointmentViewController: UIViewController {

    // sample appointments (master list)
    private var appointments: [(time: String, title: String, date: String)] = [
        ("12:00 PM", "Sudhanshu Therapy", "27.11.25"),
        ("2:00 PM", "Vishal Mentors Meet", "27.11.25"),
        ("2:30 PM", "Rishi Therapy", "27.11.25"),
        ("4:00 PM", "Sahil Therapy", "27.11.25")
    ]

    // MARK: - UI

    // REMOVED: private let gradientLayer = CAGradientLayer() -> We use GradientView now

    private let titleLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Appointments"
        l.font = .systemFont(ofSize: 34, weight: .bold)
        l.textColor = .white
        l.numberOfLines = 1
        return l
    }()

    private let addButton: UIButton = {
        let b = UIButton(type: .system)
        b.translatesAutoresizingMaskIntoConstraints = false
        let cfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .bold)
        b.setImage(UIImage(systemName: "plus", withConfiguration: cfg), for: .normal)
        b.tintColor = .white
        b.backgroundColor = UIColor(white: 1.0, alpha: 0.18)
        b.layer.cornerRadius = 26
        b.layer.masksToBounds = false
        b.layer.shadowColor = UIColor.black.cgColor
        b.layer.shadowOpacity = 0.12
        b.layer.shadowRadius = 6
        b.layer.shadowOffset = CGSize(width: 0, height: 3)
        return b
    }()

    private let calendarCard: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 22
        v.layer.masksToBounds = false
        return v
    }()

    private let monthLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = .systemFont(ofSize: 18, weight: .semibold)
        l.textColor = .black
        return l
    }()

    private let prevButton: UIButton = {
        let b = UIButton(type: .system); b.translatesAutoresizingMaskIntoConstraints = false
        b.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        b.tintColor = UIColor.systemBlue
        b.widthAnchor.constraint(equalToConstant: 36).isActive = true
        b.heightAnchor.constraint(equalToConstant: 36).isActive = true
        return b
    }()

    private let nextButton: UIButton = {
        let b = UIButton(type: .system); b.translatesAutoresizingMaskIntoConstraints = false
        b.setImage(UIImage(systemName: "chevron.right"), for: .normal)
        b.tintColor = UIColor.systemBlue
        b.widthAnchor.constraint(equalToConstant: 36).isActive = true
        b.heightAnchor.constraint(equalToConstant: 36).isActive = true
        return b
    }()

    // NOTE: Use your OTCalendarView
    private let calendarView = OTCalendarView()

    // list card
    private let listCard: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 22
        v.layer.masksToBounds = false
        return v
    }()

    private let leftAccent: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(red: 247/255, green: 152/255, blue: 50/255, alpha: 1.0)
        v.layer.cornerRadius = 20
        v.layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner]
        v.layer.masksToBounds = true
        return v
    }()

    private let tableView: UITableView = {
        let t = UITableView(); t.translatesAutoresizingMaskIntoConstraints = false
        t.backgroundColor = .clear
        t.separatorStyle = .singleLine
        t.separatorInset = UIEdgeInsets(top: 0, left: 132, bottom: 0, right: 8)
        t.showsVerticalScrollIndicator = false
        t.contentInsetAdjustmentBehavior = .never
        return t
    }()

    private var selectedDate: Date = Date()

    // MARK: - lifecycle

    // 1. UPDATE: Use GradientView as the main view
    override func loadView() {
        self.view = GradientView()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // view.backgroundColor is handled by GradientView

        // setupGradient() -> Removed, GradientView handles this
        buildHierarchy()
        setupConstraints()
        style()

        tableView.register(AppointmentTableViewCell.self, forCellReuseIdentifier: AppointmentTableViewCell.reuseId)
        tableView.dataSource = self
        tableView.delegate = self

        addButton.addTarget(self, action: #selector(addTapped), for: .touchUpInside)
        prevButton.addTarget(self, action: #selector(prevMonth), for: .touchUpInside)
        nextButton.addTarget(self, action: #selector(nextMonth), for: .touchUpInside)

        calendarView.delegate = self
        calendarView.select(date: selectedDate)
        updateMonthLabel()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }

    // MARK: - setup

    private func buildHierarchy() {
        view.addSubview(titleLabel)
        view.addSubview(addButton)

        view.addSubview(calendarCard)
        calendarCard.addSubview(monthLabel)
        calendarCard.addSubview(prevButton)
        calendarCard.addSubview(nextButton)
        calendarCard.addSubview(calendarView)

        view.addSubview(listCard)
        listCard.addSubview(leftAccent)
        listCard.addSubview(tableView)
    }

    private func setupConstraints() {
        let safe = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: safe.topAnchor, constant: 14),
            titleLabel.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 20),

            addButton.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor),
            addButton.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -18),
            addButton.widthAnchor.constraint(equalToConstant: 52),
            addButton.heightAnchor.constraint(equalToConstant: 52),

            calendarCard.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 14),
            calendarCard.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            calendarCard.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            // 2. UPDATE: Increased height from 320 to 380
            calendarCard.heightAnchor.constraint(equalToConstant: 380),

            monthLabel.topAnchor.constraint(equalTo: calendarCard.topAnchor, constant: 18),
            monthLabel.leadingAnchor.constraint(equalTo: calendarCard.leadingAnchor, constant: 18),

            nextButton.centerYAnchor.constraint(equalTo: monthLabel.centerYAnchor),
            nextButton.trailingAnchor.constraint(equalTo: calendarCard.trailingAnchor, constant: -14),

            prevButton.centerYAnchor.constraint(equalTo: monthLabel.centerYAnchor),
            prevButton.trailingAnchor.constraint(equalTo: nextButton.leadingAnchor, constant: -8),

            calendarView.topAnchor.constraint(equalTo: monthLabel.bottomAnchor, constant: 12),
            calendarView.leadingAnchor.constraint(equalTo: calendarCard.leadingAnchor, constant: 12),
            calendarView.trailingAnchor.constraint(equalTo: calendarCard.trailingAnchor, constant: -12),
            calendarView.bottomAnchor.constraint(equalTo: calendarCard.bottomAnchor, constant: -14),

            listCard.topAnchor.constraint(equalTo: calendarCard.bottomAnchor, constant: 14),
            listCard.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            listCard.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            
            // 3. UPDATE: This naturally shrinks the list card because the calendar card pushed it down
            listCard.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -12),

            leftAccent.leadingAnchor.constraint(equalTo: listCard.leadingAnchor),
            leftAccent.topAnchor.constraint(equalTo: listCard.topAnchor, constant: 10),
            leftAccent.bottomAnchor.constraint(equalTo: listCard.bottomAnchor, constant: -10),
            leftAccent.widthAnchor.constraint(equalToConstant: 36),

            tableView.leadingAnchor.constraint(equalTo: listCard.leadingAnchor, constant: 44),
            tableView.trailingAnchor.constraint(equalTo: listCard.trailingAnchor, constant: -8),
            tableView.topAnchor.constraint(equalTo: listCard.topAnchor, constant: 8),
            tableView.bottomAnchor.constraint(equalTo: listCard.bottomAnchor, constant: -8)
        ])
    }

    private func style() {
        calendarCard.layer.shadowColor = UIColor.black.cgColor
        calendarCard.layer.shadowOpacity = 0.06
        calendarCard.layer.shadowRadius = 8
        calendarCard.layer.shadowOffset = .zero
        calendarCard.layer.masksToBounds = false

        listCard.layer.shadowColor = UIColor.black.cgColor
        listCard.layer.shadowOpacity = 0.06
        listCard.layer.shadowRadius = 8
        listCard.layer.shadowOffset = .zero
        listCard.layer.masksToBounds = false

        titleLabel.layer.shadowColor = UIColor.black.cgColor
        titleLabel.layer.shadowOpacity = 0.12
        titleLabel.layer.shadowRadius = 6
        titleLabel.layer.shadowOffset = CGSize(width: 0, height: 2)
    }

    // MARK: - actions

    @objc private func addTapped() {
        let addVC = AddReminderViewController()
        addVC.delegate = self
        addVC.modalPresentationStyle = .pageSheet
        if let sheet = addVC.sheetPresentationController {
            sheet.detents = [.custom(resolver: { context in
                return context.maximumDetentValue * 0.6
            }), .large()]
            sheet.prefersGrabberVisible = true
            sheet.preferredCornerRadius = 20
        }
        present(addVC, animated: true)
    }

    @objc private func prevMonth() {
        calendarView.moveMonth(by: -1)
        updateMonthLabel()
    }

    @objc private func nextMonth() {
        calendarView.moveMonth(by: 1)
        updateMonthLabel()
    }

    private func updateMonthLabel() {
        let f = DateFormatter(); f.dateFormat = "LLLL yyyy"
        monthLabel.text = f.string(from: calendarView.currentMonth)
    }
}

// MARK: - UITableView

extension AppointmentViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { appointments.count }

    // 4. UPDATE: Reduced cell height from 92 to 72
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { 72 }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(withIdentifier: AppointmentTableViewCell.reuseId, for: indexPath) as? AppointmentTableViewCell else {
            return UITableViewCell()
        }
        let a = appointments[indexPath.row]
        cell.configure(time: a.time, title: a.title, date: a.date)
        return cell
    }

    // --- Swipe to delete (trailing) ---
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = UIContextualAction(style: .destructive, title: "Delete") { [weak self] action, view, completion in
            guard let self = self else { completion(false); return }

            // Remove from data
            self.appointments.remove(at: indexPath.row)

            // Update UI
            tableView.performBatchUpdates({
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }, completion: { _ in
                completion(true)
            })
        }
        delete.backgroundColor = UIColor.systemRed
        let config = UISwipeActionsConfiguration(actions: [delete])
        config.performsFirstActionWithFullSwipe = true // full swipe deletes
        return config
    }
}

// MARK: - OTCalendarViewDelegate
extension AppointmentViewController: OTCalendarViewDelegate {
    func calendarView(_ calendarView: OTCalendarView, didSelect date: Date) {
        selectedDate = date
        // optionally filter the list by selectedDate if you want
    }
}

// MARK: - AddReminderDelegate
extension AppointmentViewController: AddReminderDelegate {
    func didAddAppointment(title: String, subtitle: String, date: Date, time: Date) {
        let tf = DateFormatter(); tf.dateFormat = "h:mm a"
        let timeString = tf.string(from: time)
        let df = DateFormatter(); df.dateFormat = "dd.MM.yy"
        let dateString = df.string(from: date)
        let fullTitle = subtitle.isEmpty ? title : "\(title) - \(subtitle)"
        appointments.insert((time: timeString, title: fullTitle, date: dateString), at: 0)
        selectedDate = date
        calendarView.select(date: date)
        updateMonthLabel()
        DispatchQueue.main.async {
            self.tableView.reloadData()
            if !self.appointments.isEmpty {
                self.tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
            }
        }
    }
}
