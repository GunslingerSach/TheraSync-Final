//
//  OTCalendalView.swift
//  OT main
//
//  Created by user@54 on 27/11/25.
//

import UIKit

protocol OTCalendarViewDelegate: AnyObject {
    func calendarView(_ calendarView: OTCalendarView, didSelect date: Date)
}

class OTCalendarView: UIView {

    weak var delegate: OTCalendarViewDelegate?

    private var collectionView: UICollectionView!
    private var days: [Date?] = []
    private let calendar = Calendar.current
    private var selectedDateInternal: Date = Date()
    private(set) var currentMonth: Date = Date()

    private lazy var weekdayStack: UIStackView = {
        let syms = calendar.shortWeekdaySymbols
        let labels = syms.map { (s) -> UILabel in
            let l = UILabel(); l.text = s.uppercased()
            l.font = .systemFont(ofSize: 12, weight: .semibold)
            l.textColor = UIColor.systemGray
            l.textAlignment = .center
            return l
        }
        let st = UIStackView(arrangedSubviews: labels)
        st.translatesAutoresizingMaskIntoConstraints = false
        st.axis = .horizontal
        st.distribution = .fillEqually
        return st
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        translatesAutoresizingMaskIntoConstraints = false
        backgroundColor = .clear
        setupCollection()
        generateMonth(for: Date())
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }

    private func setupCollection() {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 8
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.backgroundColor = .clear
        cv.register(OTCalendarDayCell.self, forCellWithReuseIdentifier: OTCalendarDayCell.reuseId)
        cv.dataSource = self
        cv.delegate = self
        addSubview(weekdayStack)
        addSubview(cv)
        self.collectionView = cv

        NSLayoutConstraint.activate([
            weekdayStack.topAnchor.constraint(equalTo: topAnchor, constant: 6),
            weekdayStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 6),
            weekdayStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            weekdayStack.heightAnchor.constraint(equalToConstant: 20),

            cv.topAnchor.constraint(equalTo: weekdayStack.bottomAnchor, constant: 8),
            cv.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 6),
            cv.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            cv.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -6)
        ])
    }

    func generateMonth(for date: Date) {
        currentMonth = firstOfMonth(for: date)
        days.removeAll()
        let range = calendar.range(of: .day, in: .month, for: currentMonth)!
        let comps = calendar.dateComponents([.weekday], from: currentMonth)
        let weekdayOfFirst = (comps.weekday ?? 1)
        let leadingEmpty = weekdayOfFirst - calendar.firstWeekday
        let padding = (leadingEmpty + 7) % 7
        for _ in 0..<padding { days.append(nil) }
        for d in range {
            if let dayDate = calendar.date(byAdding: .day, value: d - 1, to: currentMonth) {
                days.append(dayDate)
            }
        }
        collectionView.reloadData()
    }

    func select(date: Date) {
        selectedDateInternal = date
        if !isSameMonth(date1: date, date2: currentMonth) {
            generateMonth(for: date)
        }
        collectionView.reloadData()
    }

    func moveMonth(by offset: Int) {
        if let newMonth = calendar.date(byAdding: .month, value: offset, to: currentMonth) {
            generateMonth(for: newMonth)
        }
    }

    // helpers
    private func firstOfMonth(for date: Date) -> Date {
        let comps = calendar.dateComponents([.year, .month], from: date)
        return calendar.date(from: comps)!
    }
    private func isSameDay(date1: Date, date2: Date) -> Bool {
        calendar.isDate(date1, inSameDayAs: date2)
    }
    private func isSameMonth(date1: Date, date2: Date) -> Bool {
        let a = calendar.dateComponents([.year, .month], from: date1)
        let b = calendar.dateComponents([.year, .month], from: date2)
        return a.year == b.year && a.month == b.month
    }
}

extension OTCalendarView: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    func collectionView(_ cv: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return days.count
    }

    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = cv.dequeueReusableCell(withReuseIdentifier: OTCalendarDayCell.reuseId, for: indexPath) as? OTCalendarDayCell else {
            return UICollectionViewCell()
        }
        if let d = days[indexPath.item] {
            let day = Calendar.current.component(.day, from: d)
            let isToday = isSameDay(date1: d, date2: Date())
            let isSelected = isSameDay(date1: d, date2: selectedDateInternal)
            cell.configure(day: "\(day)", isToday: isToday, isSelected: isSelected)
            cell.alpha = 1.0
        } else {
            cell.configure(day: "", isToday: false, isSelected: false)
            cell.alpha = 0.0
        }
        return cell
    }

    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let d = days[indexPath.item] else { return }
        selectedDateInternal = d
        cv.reloadData()
        delegate?.calendarView(self, didSelect: d)
    }

    func collectionView(_ cv: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let total = collectionView.bounds.width
        let w = floor(total / 7.0)
        return CGSize(width: w, height: 44)
    }
}

// small day cell
private class OTCalendarDayCell: UICollectionViewCell {
    static let reuseId = "OTCalendarDayCell"
    private let label: UILabel = {
        let l = UILabel(); l.translatesAutoresizingMaskIntoConstraints = false
        l.font = .systemFont(ofSize: 16, weight: .regular)
        l.textAlignment = .center
        return l
    }()
    private let circle: UIView = {
        let v = UIView(); v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 20
        v.isHidden = true
        return v
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(circle)
        contentView.addSubview(label)
        NSLayoutConstraint.activate([
            circle.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            circle.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            circle.widthAnchor.constraint(equalToConstant: 40),
            circle.heightAnchor.constraint(equalToConstant: 40),
            label.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }
    func configure(day: String, isToday: Bool, isSelected: Bool) {
        label.text = day
        if day.isEmpty { label.textColor = .clear } else { label.textColor = isSelected ? .white : .black }
        circle.isHidden = !isSelected
        circle.backgroundColor = isToday ? UIColor(red: 100/255, green: 170/255, blue: 255/255, alpha: 1.0) : UIColor(red: 74/255, green: 137/255, blue: 255/255, alpha: 1.0)
        label.font = isSelected ? .systemFont(ofSize: 18, weight: .bold) : .systemFont(ofSize: 16, weight: .regular)
    }
}
