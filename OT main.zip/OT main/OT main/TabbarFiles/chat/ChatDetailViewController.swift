//
//  ChatDetailViewController.swift
//  Screens1
//
//  Created by user@54 on 16/11/25.
//

// ChatDetailViewController.swift
import UIKit

struct ChatMessage {
    let text: String
    let isIncoming: Bool
}

class ChatDetailViewController: UIViewController {

    var titleName: String?

    private var messages: [ChatMessage] = [
        ChatMessage(text: "Hello!", isIncoming: true),
        ChatMessage(text: "Hi, how can I help you today?", isIncoming: false),
        ChatMessage(text: "Can you check the file I sent?", isIncoming: true),
        ChatMessage(text: "Sure, I’ll check it.", isIncoming: false)
    ]

    private let headerView = UIView()
    private let backButton = UIButton(type: .system)
    private let titleLabel = UILabel()

    private let tableView = UITableView()
    // inputContainer used as inputAccessoryView; DO NOT add it as subview to main view
    private lazy var inputContainer: UIView = {
        // Load from nib if available, otherwise create minimal programmatic UI
        if Bundle.main.path(forResource: "ChatInputAccessoryView", ofType: "nib") != nil {
            let accessory = ChatInputAccessoryView.loadFromNib()
            accessory.delegate = self
            return accessory
        } else {
            // programmatic fallback
            let v = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.width, height: 56))
            v.backgroundColor = .secondarySystemBackground

            let tf = UITextField()
            tf.placeholder = "Message"
            tf.borderStyle = .roundedRect
            tf.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(tf)

            let send = UIButton(type: .system)
            send.setTitle("Send", for: .normal)
            send.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(send)

            NSLayoutConstraint.activate([
                tf.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 12),
                tf.centerYAnchor.constraint(equalTo: v.centerYAnchor),
                send.leadingAnchor.constraint(equalTo: tf.trailingAnchor, constant: 8),
                send.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -12),
                tf.heightAnchor.constraint(equalToConstant: 36),
                send.centerYAnchor.constraint(equalTo: v.centerYAnchor),
                tf.trailingAnchor.constraint(lessThanOrEqualTo: send.leadingAnchor, constant: -8)
            ])
            send.addTarget(self, action: #selector(sendProgrammatic(_:)), for: .touchUpInside)
            return v
        }
    }()

    override var inputAccessoryView: UIView? { inputContainer }
    override var canBecomeFirstResponder: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        navigationController?.navigationBar.isHidden = true

        setupHeader()
        setupTable()
        // do not add inputContainer as subview; it's returned via inputAccessoryView

        // crucial: configure table insets so messages don't get hidden by accessory
        configureTableInsetsForAccessory()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        becomeFirstResponder() // attach accessory above keyboard
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        resignFirstResponder()
    }

    // MARK: Header
    private func setupHeader() {
        headerView.backgroundColor = UIColor(red: 0.15, green: 0.52, blue: 1, alpha: 1)
        headerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerView)

        NSLayoutConstraint.activate([
            headerView.topAnchor.constraint(equalTo: view.topAnchor),
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 110)
        ])

        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.layer.cornerRadius = 22
        backButton.backgroundColor = UIColor.white.withAlphaComponent(0.2)
        backButton.addTarget(self, action: #selector(backTap), for: .touchUpInside)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        headerView.addSubview(backButton)

        titleLabel.text = titleName ?? "Chat"
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        headerView.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            backButton.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            backButton.bottomAnchor.constraint(equalTo: headerView.bottomAnchor, constant: -16),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerYAnchor.constraint(equalTo: backButton.centerYAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor)
        ])
    }

    @objc private func backTap() {
        navigationController?.popViewController(animated: true)
    }

    // MARK: Table
    private func setupTable() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .systemBackground
        tableView.separatorStyle = .none
        tableView.keyboardDismissMode = .interactive
        tableView.dataSource = self
        tableView.delegate = self

        tableView.register(IncomingBubble.self, forCellReuseIdentifier: "Incoming")
        tableView.register(OutgoingBubble.self, forCellReuseIdentifier: "Outgoing")

        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func configureTableInsetsForAccessory() {
        tableView.keyboardDismissMode = .interactive
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .automatic
        }
        // Input accessory intrinsic height ~56; add cushion
        let accessoryHeight: CGFloat = 56
        tableView.contentInset.bottom = accessoryHeight + view.safeAreaInsets.bottom + 8
        tableView.scrollIndicatorInsets.bottom = accessoryHeight + view.safeAreaInsets.bottom + 8
    }

    @objc private func sendProgrammatic(_ sender: UIButton) {
        // fallback send for programmatic accessory
        if let tf = (inputContainer.subviews.compactMap{ $0 as? UITextField }.first),
           let text = tf.text, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            messages.append(ChatMessage(text: text, isIncoming: false))
            tf.text = ""
            tableView.reloadData()
            tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
        }
    }
}

// MARK: - DataSource / Delegate
extension ChatDetailViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { messages.count }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let msg = messages[indexPath.row]

        if msg.isIncoming {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Incoming", for: indexPath) as! IncomingBubble
            cell.setText(msg.text)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Outgoing", for: indexPath) as! OutgoingBubble
            cell.setText(msg.text)
            return cell
        }
    }
}

// MARK: - Bubbles
// ---- Paste this to replace your existing IncomingBubble and OutgoingBubble classes ----

class IncomingBubble: UITableViewCell {
    private let bubbleView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0.94, alpha: 1) // light grey like iMessage incoming
        v.layer.cornerRadius = 18
        v.layer.masksToBounds = true
        return v
    }()

    private let messageLabel: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.numberOfLines = 0
        lbl.font = UIFont.systemFont(ofSize: 16) // bigger font
        lbl.textColor = .label
        lbl.lineBreakMode = .byWordWrapping
        return lbl
    }()

    // padding values
    private let horizontalPadding: CGFloat = 14
    private let verticalPadding: CGFloat = 10
    // max bubble width relative to the screen
    private let maxBubbleWidthMultiplier: CGFloat = 0.72

    private var bubbleLeadingConstraint: NSLayoutConstraint!
    private var bubbleTrailingConstraint: NSLayoutConstraint!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none

        contentView.addSubview(bubbleView)
        bubbleView.addSubview(messageLabel)

        // constraints: bubble inside contentView
        bubbleLeadingConstraint = bubbleView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16)
        bubbleTrailingConstraint = bubbleView.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -80)

        NSLayoutConstraint.activate([
            bubbleLeadingConstraint,
            bubbleTrailingConstraint,
            bubbleView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            bubbleView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),

            // messageLabel inside bubble with padding
            messageLabel.leadingAnchor.constraint(equalTo: bubbleView.leadingAnchor, constant: horizontalPadding),
            messageLabel.trailingAnchor.constraint(equalTo: bubbleView.trailingAnchor, constant: -horizontalPadding),
            messageLabel.topAnchor.constraint(equalTo: bubbleView.topAnchor, constant: verticalPadding),
            messageLabel.bottomAnchor.constraint(equalTo: bubbleView.bottomAnchor, constant: -verticalPadding),

            // max width so bubble wraps nicely
            bubbleView.widthAnchor.constraint(lessThanOrEqualTo: contentView.widthAnchor, multiplier: maxBubbleWidthMultiplier)
        ])
    }

    func setText(_ text: String) {
        messageLabel.text = text
    }
}

class OutgoingBubble: UITableViewCell {
    private let bubbleView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor.systemBlue
        v.layer.cornerRadius = 18
        v.layer.masksToBounds = true
        return v
    }()

    private let messageLabel: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.numberOfLines = 0
        lbl.font = UIFont.systemFont(ofSize: 16)
        lbl.textColor = .white
        lbl.lineBreakMode = .byWordWrapping
        return lbl
    }()

    private let horizontalPadding: CGFloat = 14
    private let verticalPadding: CGFloat = 10
    private let maxBubbleWidthMultiplier: CGFloat = 0.72

    private var bubbleLeadingConstraint: NSLayoutConstraint!
    private var bubbleTrailingConstraint: NSLayoutConstraint!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none

        contentView.addSubview(bubbleView)
        bubbleView.addSubview(messageLabel)

        // trailing aligned for outgoing (right side)
        bubbleTrailingConstraint = bubbleView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16)
        bubbleLeadingConstraint = bubbleView.leadingAnchor.constraint(greaterThanOrEqualTo: contentView.leadingAnchor, constant: 80)

        NSLayoutConstraint.activate([
            bubbleLeadingConstraint,
            bubbleTrailingConstraint,
            bubbleView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            bubbleView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),

            // messageLabel padding
            messageLabel.leadingAnchor.constraint(equalTo: bubbleView.leadingAnchor, constant: horizontalPadding),
            messageLabel.trailingAnchor.constraint(equalTo: bubbleView.trailingAnchor, constant: -horizontalPadding),
            messageLabel.topAnchor.constraint(equalTo: bubbleView.topAnchor, constant: verticalPadding),
            messageLabel.bottomAnchor.constraint(equalTo: bubbleView.bottomAnchor, constant: -verticalPadding),

            // max width
            bubbleView.widthAnchor.constraint(lessThanOrEqualTo: contentView.widthAnchor, multiplier: maxBubbleWidthMultiplier)
        ])
    }

    func setText(_ text: String) {
        messageLabel.text = text
    }
}


// Hook accessory delegate when nib-based accessory exists
extension ChatDetailViewController: ChatInputAccessoryViewDelegate {
    func sendButtonTapped(text: String) {
        messages.append(ChatMessage(text: text, isIncoming: false))
        tableView.reloadData()
        tableView.scrollToRow(at: IndexPath(row: messages.count - 1, section: 0), at: .bottom, animated: true)
    }
}
