//
//  Notifications.swift
//  OT main
//
//  Created by user@54 on 27/11/25.
//

// Notifications.swift
import Foundation

extension Notification.Name {
    static let didAddPatient = Notification.Name("didAddPatient")
}
