//
//  ChatListViewController.swift
//  Screens1
//
//  Created by user@54 on 16/11/25.
//

// ChatListViewController.swift

// ChatListViewController.swift
import UIKit

struct ChatSummary {
    let id: UUID
    let name: String
    let message: String
    let time: String
    let avatar: UIImage?
}

class ChatListViewController: UIViewController,
                              UITableViewDataSource,
                              UITableViewDelegate,
                              UISearchBarDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar?

    private let titleLabel: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.text = "Chat"
        lbl.font = .systemFont(ofSize: 34, weight: .bold)
        lbl.textColor = .white
        return lbl
    }()

    private let topAddButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.translatesAutoresizingMaskIntoConstraints = false
        let cfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .bold)
        btn.setImage(UIImage(systemName: "plus", withConfiguration: cfg), for: .normal)
        btn.tintColor = .white
        btn.backgroundColor = UIColor(white: 1, alpha: 0.18)
        btn.layer.cornerRadius = 22
        return btn
    }()

    private let containerView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .systemBackground
        v.layer.cornerRadius = 22
        v.layer.masksToBounds = true
        return v
    }()

    private var chats: [ChatSummary] = []
    private var filteredChats: [ChatSummary] = []
    private var originalChats: [ChatSummary] = []

    private var isSearching: Bool {
        guard let sb = searchBar else { return false }
        let t = sb.text ?? ""
        return !t.trimmingCharacters(in: .whitespaces).isEmpty
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.setNavigationBarHidden(true, animated: false)

        setupTable()
        setupSearchBar()
        loadSampleData()

        NotificationCenter.default.addObserver(self, selector: #selector(handlePatientAdded(_:)), name: .didAddPatient, object: nil)
        topAddButton.isHidden = true

        if let sb = searchBar {
            deactivateConstraintsReferencing(view: view, target: sb)
            sb.removeConstraints(sb.constraints)
            sb.translatesAutoresizingMaskIntoConstraints = false
        }
        if let tv = tableView {
            deactivateConstraintsReferencing(view: view, target: tv)
            tv.removeConstraints(tv.constraints)
            tv.translatesAutoresizingMaskIntoConstraints = false
        }

        layoutUI()
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func layoutUI() {
        view.addSubview(titleLabel)
        view.addSubview(topAddButton)
        view.addSubview(containerView)
        containerView.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false

        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: safe.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 20),

            topAddButton.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor),
            topAddButton.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -20),
            topAddButton.widthAnchor.constraint(equalToConstant: 44),
            topAddButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        if let sb = searchBar {
            sb.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(sb)

            NSLayoutConstraint.activate([
                sb.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 12),
                sb.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 12),
                sb.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -12),
                sb.heightAnchor.constraint(equalToConstant: 50),

                containerView.topAnchor.constraint(equalTo: sb.bottomAnchor, constant: 8),
                containerView.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 12),
                containerView.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -12),
                containerView.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -12)
            ])
        } else {
            NSLayoutConstraint.activate([
                containerView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 12),
                containerView.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 12),
                containerView.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -12),
                containerView.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -12)
            ])
        }

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: containerView.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)
        ])

        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        }
    }

    private func setupTable() {
        if Bundle.main.path(forResource: "ChatCell", ofType: "nib") != nil {
            tableView.register(UINib(nibName: "ChatCell", bundle: nil), forCellReuseIdentifier: "ChatCell")
        }
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .singleLine
        tableView.backgroundColor = .clear
        tableView.estimatedRowHeight = 90
        tableView.rowHeight = UITableView.automaticDimension
        tableView.contentInset = UIEdgeInsets(top: 6, left: 0, bottom: 0, right: 0)
    }

    private func setupSearchBar() {
        guard let sb = searchBar else { return }
        sb.delegate = self
        sb.placeholder = "Search"
        sb.searchBarStyle = .minimal
        sb.backgroundImage = UIImage()
        if let tf = sb.value(forKey: "searchField") as? UITextField {
            tf.backgroundColor = UIColor(white: 1, alpha: 0.95)
            tf.layer.cornerRadius = 20
            tf.clipsToBounds = true
        }
    }

    private func loadSampleData() {
        let names = ["Ashutosh Anand", "Ravi Kumar", "Neha Sharma", "Priya Verma"]
        let msgs = ["Hey, I'll check and get back to you.","Sure — noted.","Thanks!","Ok sir..."]

        var arr: [ChatSummary] = []
        for i in 0..<10 {
            let n = names[i % names.count]
            let m = msgs[i % msgs.count]
            let time = String(format: "%02d:%02d", 20 + (i/6), i % 60)
            arr.append(ChatSummary(id: UUID(), name: n, message: m, time: time, avatar: UIImage(named: "avatar_placeholder")))
        }
        chats = arr
        filteredChats = arr
        originalChats = arr
        tableView.reloadData()
    }

    // MARK: - Notifications
    @objc private func handlePatientAdded(_ note: Notification) {
        guard let patient = note.object as? Patient else { return }
        let fullName = "\(patient.firstName) \(patient.lastName)".trimmingCharacters(in: .whitespaces)
        let fmt = DateFormatter(); fmt.dateFormat = "HH:mm"
        let newChat = ChatSummary(id: UUID(), name: fullName.isEmpty ? "New Patient" : fullName, message: "Tap to start chat", time: fmt.string(from: Date()), avatar: UIImage(named: "avatar_placeholder"))
        chats = [newChat]
        filteredChats = chats
        tableView.reloadData()
        if chats.count > 0 {
            tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        }
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Show All", style: .plain, target: self, action: #selector(showAllTapped))
    }

    @objc private func showAllTapped() {
        chats = originalChats
        filteredChats = originalChats
        tableView.reloadData()
        navigationItem.rightBarButtonItem = nil
    }

    private func deactivateConstraintsReferencing(view root: UIView, target: UIView) {
        var toDeactivate: [NSLayoutConstraint] = []
        func collect(in view: UIView) {
            for c in view.constraints {
                if let first = c.firstItem as? UIView, first == target { toDeactivate.append(c) }
                if let second = c.secondItem as? UIView, second == target { toDeactivate.append(c) }
            }
            for sub in view.subviews { collect(in: sub) }
        }
        collect(in: root)
        for c in target.constraints { toDeactivate.append(c) }
        NSLayoutConstraint.deactivate(Array(Set(toDeactivate)))
    }

    // MARK: Table datasource / delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearching ? filteredChats.count : chats.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let item = isSearching ? filteredChats[indexPath.row] : chats[indexPath.row]

        if let cell = tableView.dequeueReusableCell(withIdentifier: "ChatCell", for: indexPath) as? ChatCell {
            cell.configure(with: item)
            return cell
        }

        let fallback = UITableViewCell(style: .subtitle, reuseIdentifier: "fallbackCell")
        fallback.textLabel?.text = item.name
        fallback.detailTextLabel?.text = item.message
        fallback.selectionStyle = .none
        return fallback
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = isSearching ? filteredChats[indexPath.row] : chats[indexPath.row]
        let detailVC = ChatDetailViewController()
        detailVC.titleName = item.name
        // hide tab bar for full-screen chat (matches Figma)
        detailVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(detailVC, animated: true)
    }

    // swipe to delete
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let del = UIContextualAction(style: .destructive, title: "Delete") { [weak self] action, view, completion in
            guard let self = self else { completion(false); return }
            if self.isSearching {
                let removed = self.filteredChats.remove(at: indexPath.row)
                self.chats.removeAll { $0.id == removed.id }
            } else {
                self.chats.remove(at: indexPath.row)
            }
            tableView.deleteRows(at: [indexPath], with: .automatic)
            completion(true)
        }
        return UISwipeActionsConfiguration(actions: [del])
    }

    // MARK: searchbar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredChats = chats
        } else {
            filteredChats = chats.filter { $0.name.lowercased().contains(searchText.lowercased()) || $0.message.lowercased().contains(searchText.lowercased()) }
        }
        tableView.reloadData()
    }
}

