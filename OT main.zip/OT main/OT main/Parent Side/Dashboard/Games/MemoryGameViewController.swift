import UIKit
import AVFoundation

class MemoryGameViewController: UIViewController {

    private var sequence: [Int] = []
    private var inputIndex: Int = 0
    private var isPlayerTurn = false
    private var isGameActive = true
    private let maxLevel = 7
    private let hapticGenerator = UIImpactFeedbackGenerator(style: .light)
    private var audioPlayer: AVAudioPlayer?
    
    private let tileColors: [UIColor] = [
        UIColor(red: 0.68, green: 0.82, blue: 0.95, alpha: 1.0),
        UIColor(red: 0.95, green: 0.72, blue: 0.72, alpha: 1.0),
        UIColor(red: 0.75, green: 0.90, blue: 0.80, alpha: 1.0),
        UIColor(red: 0.98, green: 0.92, blue: 0.75, alpha: 1.0),
        UIColor(red: 0.90, green: 0.80, blue: 0.95, alpha: 1.0),
        UIColor(red: 1.00, green: 0.85, blue: 0.75, alpha: 1.0)
    ]
    
    // UI Components
    private lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer()
        layer.colors = [UIColor(red: 0.95, green: 0.98, blue: 1.0, alpha: 1.0).cgColor, UIColor(red: 0.92, green: 0.92, blue: 0.98, alpha: 1.0).cgColor]
        return layer
    }()

    private let statusLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Press Start to Play"
        lbl.font = .systemFont(ofSize: 24, weight: .semibold)
        lbl.textColor = .darkGray
        lbl.textAlignment = .center
        lbl.translatesAutoresizingMaskIntoConstraints = false
        return lbl
    }()

    private let gridStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical; stack.distribution = .fillEqually; stack.spacing = 25
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    private let startButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Start Game", for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 22, weight: .bold)
        btn.backgroundColor = UIColor(red: 0.45, green: 0.70, blue: 0.90, alpha: 1.0)
        btn.setTitleColor(.white, for: .normal); btn.layer.cornerRadius = 30
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()

    private var tileButtons: [UIButton] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(applyTheme), name: NSNotification.Name("AppThemeChanged"), object: nil)
        setupNavigationBar()
        setupUI()
        createGrid()
        
        // CALL THIS HERE to apply saved settings immediately on load
        applyTheme()
        
        startButton.addTarget(self, action: #selector(startGame), for: .touchUpInside)
        hapticGenerator.prepare()
    }

    @objc private func applyTheme() {
        let isHighContrast = UserDefaults.standard.bool(forKey: "High Contrast")
        
        // UI updates must happen on the main thread
        DispatchQueue.main.async {
            // 1. Update Background
            if isHighContrast {
                self.gradientLayer.isHidden = true
                self.view.backgroundColor = .white
            } else {
                self.gradientLayer.isHidden = false
            }

            // 2. Update Tiles
            self.tileButtons.forEach {
                if isHighContrast {
                    $0.layer.borderWidth = 6
                    $0.layer.borderColor = UIColor.black.cgColor
                } else {
                    $0.layer.borderWidth = 4
                    $0.layer.borderColor = UIColor.white.cgColor
                }
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isGameActive = true
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isGameActive = false
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        tileButtons.forEach { $0.layer.removeAllAnimations() }
        // Force hide immediately to prevent title overlap glitch on return
        navigationController?.setNavigationBarHidden(true, animated: false)
    }

    private func setupNavigationBar() {
        title = "Memorizo"
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [.font: UIFont.systemFont(ofSize: 22, weight: .bold)]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }

    private func flashTile(at index: Int) {
        guard isGameActive else { return }
        
        let shouldReduceMotion = UserDefaults.standard.bool(forKey: "Reduced Motion")
        let globalHapticsEnabled = UserDefaults.standard.bool(forKey: "Global Haptics")
        let isHighContrast = UserDefaults.standard.bool(forKey: "High Contrast")
        
        // 1. RELIABLE SYSTEM SOUND (1104 is the system 'Tock')
        // This works on all devices even without an audio file.
        AudioServicesPlaySystemSound(1104)
        
        if globalHapticsEnabled {
            hapticGenerator.impactOccurred()
        }
        
        let btn = tileButtons[index]
        let duration = shouldReduceMotion ? 0.0 : 0.3
        let scale: CGFloat = shouldReduceMotion ? 1.0 : 0.9
        
        let normalBorderColor = isHighContrast ? UIColor.black.cgColor : UIColor.white.cgColor
        let activeBorderColor = isHighContrast ? UIColor.systemYellow.cgColor : UIColor.white.cgColor
        
        UIView.animate(withDuration: duration, animations: {
            btn.alpha = 0.3
            btn.transform = CGAffineTransform(scaleX: scale, y: scale)
            if isHighContrast {
                btn.layer.borderColor = activeBorderColor
            }
        }) { _ in
            guard self.isGameActive else { return }
            UIView.animate(withDuration: duration) {
                btn.alpha = 1.0
                btn.transform = .identity
                btn.layer.borderColor = normalBorderColor
            }
        }
    }

    // Update this to handle the Game Over sound specifically
    private func playCappedSound(volume: Float) {
        // 1052 is the "System Alert" sound - it is much louder and more reliable than 1053
        AudioServicesPlaySystemSound(1052)
    }
    private func setupUI() {
        view.layer.insertSublayer(gradientLayer, at: 0)
        gradientLayer.frame = view.bounds
        view.addSubview(statusLabel)
        view.addSubview(gridStackView)
        view.addSubview(startButton)
        
        let safe = view.safeAreaLayoutGuide
        
        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: safe.topAnchor, constant: 15),
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.heightAnchor.constraint(equalToConstant: 40),

            startButton.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -25),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.widthAnchor.constraint(equalToConstant: 220),
            startButton.heightAnchor.constraint(equalToConstant: 60),

            // Constrain the center of the grid
            gridStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            gridStackView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -10),
            
            // LIMIT the grid width so it doesn't get too wide on iPads/Large phones
            gridStackView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75),
            
            // ENSURE the grid stays between the label and button
            gridStackView.topAnchor.constraint(greaterThanOrEqualTo: statusLabel.bottomAnchor, constant: 10),
            gridStackView.bottomAnchor.constraint(lessThanOrEqualTo: startButton.topAnchor, constant: -10)
        ])
    }

    private func createGrid() {
        // Clear existing views to avoid duplicates
        gridStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        tileButtons.removeAll()
        
        let spacingValue: CGFloat = view.frame.height < 600 ? 15 : 25
        gridStackView.spacing = spacingValue
        
        var tag = 0
        for _ in 0..<3 {
            let row = UIStackView()
            row.axis = .horizontal
            row.distribution = .fillEqually
            row.spacing = spacingValue
            
            for _ in 0..<2 {
                let btn = UIButton()
                btn.backgroundColor = tileColors[tag]
                btn.layer.cornerRadius = 20
                btn.tag = tag
                btn.layer.borderWidth = 3
                btn.layer.borderColor = UIColor.white.cgColor
                btn.addTarget(self, action: #selector(tileTapped), for: .touchUpInside)
                
                // --- THE FIX: FORCED SQUARE ASPECT ---
                btn.translatesAutoresizingMaskIntoConstraints = false
                // 1. Force Height to equal Width
                btn.heightAnchor.constraint(equalTo: btn.widthAnchor).isActive = true
                
                tileButtons.append(btn)
                row.addArrangedSubview(btn)
                tag += 1
            }
            gridStackView.addArrangedSubview(row)
        }
    }
    @objc private func startGame() { sequence.removeAll(); startButton.isHidden = true; startNewRound() }

    private func startNewRound() {
        if sequence.count == maxLevel { gameCompleted(); return }
        sequence.append(Int.random(in: 0..<6))
        inputIndex = 0; isPlayerTurn = false; statusLabel.text = "Watch..."
        playSequenceAnimation()
    }

    private func playSequenceAnimation() {
        view.isUserInteractionEnabled = false
        for (index, tileIndex) in sequence.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + (0.9 * Double(index) + 0.5)) {
                self.flashTile(at: tileIndex)
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + (0.9 * Double(sequence.count) + 0.5)) {
            guard self.isGameActive else { return }
            self.view.isUserInteractionEnabled = true; self.isPlayerTurn = true
            self.statusLabel.text = "Your Turn! (Level \(self.sequence.count))"
        }
    }

    @objc private func tileTapped(_ sender: UIButton) {
        guard isPlayerTurn else { return }
        flashTile(at: sender.tag)
        if sender.tag == sequence[inputIndex] {
            inputIndex += 1
            if inputIndex == sequence.count {
                isPlayerTurn = false; statusLabel.text = "Excellent!"
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { self.startNewRound() }
            }
        } else { gameOver() }
    }

    private func gameCompleted() {
        AudioServicesPlaySystemSound(1025)
        let alert = UIAlertController(title: "Game Completed! 🎉", message: "Level 7 Mastered!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Finish", style: .default) { _ in self.navigationController?.popViewController(animated: true) })
        present(alert, animated: true)
    }

    private func gameOver() {
        playCappedSound(volume: 1.0)
        
        startButton.isHidden = false
        statusLabel.text = "Let's try again!"
        let alert = UIAlertController(title: "Nice Effort!", message: "Try again?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes!", style: .default) { _ in self.startGame() })
        present(alert, animated: true)
    }
}
