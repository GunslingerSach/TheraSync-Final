import UIKit

final class QuickAccessCard: UIControl {

    init(title: String, count: String?, color: UIColor) {
        super.init(frame: .zero)
        backgroundColor = color
        layer.cornerRadius = 20

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.textColor = .white
        titleLabel.font = .systemFont(ofSize: 16, weight: .bold)

        let countLabel = UILabel()
        countLabel.text = count
        countLabel.textColor = .white
        countLabel.font = .systemFont(ofSize: 18, weight: .bold)

        [titleLabel, countLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            addSubview($0)
        }

        NSLayoutConstraint.activate([
            heightAnchor.constraint(equalToConstant: 80),

            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            titleLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),

            countLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            countLabel.topAnchor.constraint(equalTo: topAnchor, constant: 12)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError()
    }
}
