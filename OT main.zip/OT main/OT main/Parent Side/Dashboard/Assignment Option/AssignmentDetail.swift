import UIKit

class AssignmentDetailViewController: UIViewController {
    var assignmentTitle: String?
    
    private let scrollView = UIScrollView()
    private let contentStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        setupNavBarAppearance()
        setupUI()
    }
    private func setupNavBarAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.titleTextAttributes = [
            .font: UIFont.systemFont(ofSize: 18, weight: .bold),
            .foregroundColor: UIColor.black
        ]
        
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        // Sets the title in the navigation bar instead of a manual label
        self.title = assignmentTitle
        navigationController?.navigationBar.tintColor = .black
    }
    
    private func setupUI() {
        // 1. Background
        let bg = ParentGradientView()
        bg.frame = view.bounds
        view.addSubview(bg)

        // 2. Scroll View & Stack
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentStack)

        let safeArea = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            // Pinned to safe area top to avoid overlapping with the navigation bar
            scrollView.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 10),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            contentStack.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 20),
            contentStack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 20),
            contentStack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -20),
            contentStack.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -20),
            contentStack.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -40)
        ])

        addDetailComponents()
    }
    
    private func addDetailComponents() {
        // Video Placeholder
        let videoBox = UIView()
        videoBox.backgroundColor = .white
        videoBox.layer.cornerRadius = 20
        videoBox.translatesAutoresizingMaskIntoConstraints = false
        videoBox.heightAnchor.constraint(equalToConstant: 200).isActive = true
        
        let playIcon = UIImageView(image: UIImage(systemName: "play.fill"))
        playIcon.tintColor = .black
        playIcon.translatesAutoresizingMaskIntoConstraints = false
        
        videoBox.addSubview(playIcon)
        
        NSLayoutConstraint.activate([
            playIcon.centerXAnchor.constraint(equalTo: videoBox.centerXAnchor),
            playIcon.centerYAnchor.constraint(equalTo: videoBox.centerYAnchor),
            playIcon.widthAnchor.constraint(equalToConstant: 40),
            playIcon.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        contentStack.addArrangedSubview(videoBox)
        
        // Buttons
        contentStack.addArrangedSubview(createButton(title: "Watch Video", color: UIColor(red: 0.24, green: 0.51, blue: 1.0, alpha: 1.0)))
        contentStack.addArrangedSubview(createButton(title: "Record Video", color: UIColor(red: 1.0, green: 0.7, blue: 0.3, alpha: 1.0)))
        
        // Questions
        for i in 1...3 {
            let qLabel = UILabel()
            qLabel.text = "\(i). Question \(i)"
            qLabel.font = .systemFont(ofSize: 18, weight: .bold)
            contentStack.addArrangedSubview(qLabel)
            
            let field = UITextField()
            field.placeholder = "Answer"
            field.backgroundColor = .white
            field.layer.cornerRadius = 20
            field.translatesAutoresizingMaskIntoConstraints = false
            
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: 50))
            field.leftView = paddingView
            field.leftViewMode = .always
            
            field.heightAnchor.constraint(equalToConstant: 50).isActive = true
            contentStack.addArrangedSubview(field)
        }
        
        contentStack.addArrangedSubview(createButton(title: "Mark as complete", color: UIColor(red: 0.24, green: 0.51, blue: 1.0, alpha: 1.0)))
    }

    private func createButton(title: String, color: UIColor) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.backgroundColor = color
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.heightAnchor.constraint(equalToConstant: 55).isActive = true
        return btn
    }
}
