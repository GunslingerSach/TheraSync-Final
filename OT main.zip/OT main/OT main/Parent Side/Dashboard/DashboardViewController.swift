import UIKit

final class DashboardViewController: UIViewController {

    // MARK: - UI Components

    private let titleLabel: UILabel = {
        let l = UILabel()
        l.text = "Dashboard"
        l.font = .systemFont(ofSize: 34, weight: .bold)
        l.textColor = .black
        return l
    }()

    private let subtitleLabel: UILabel = {
        let l = UILabel()
        l.text = "Hi Ashutosh"
        l.font = .systemFont(ofSize: 22, weight: .semibold)
        l.textColor = .black
        return l
    }()

    private let progressArc = ProgressArcView()

    private let percentLabel: UILabel = {
        let l = UILabel()
        l.text = "33%"
        l.font = .systemFont(ofSize: 28, weight: .bold)
        l.textAlignment = .center
        return l
    }()

    private let progressTextLabel: UILabel = {
        let l = UILabel()
        l.text = "Progress Complete"
        l.font = .systemFont(ofSize: 14, weight: .medium)
        l.textAlignment = .center
        return l
    }()

    private let quickAccessLabel: UILabel = {
        let l = UILabel()
        l.text = "Quick Access"
        l.font = .systemFont(ofSize: 22, weight: .bold)
        l.textColor = .black
        return l
    }()
    // Cards
    private let assignmentCard = QuickAccessCard(
        title: "Assignment",
        count: "5",
        color: UIColor(red: 0.95, green: 0.30, blue: 0.36, alpha: 1)
    )

    private let appointmentCard = QuickAccessCard(
        title: "Appointment",
        count: "2",
        color: UIColor(red: 0.26, green: 0.52, blue: 0.96, alpha: 1)
    )

    private let chatCard = QuickAccessCard(
        title: "Chat",
        count: nil,
        color: UIColor(red: 0.36, green: 0.75, blue: 0.39, alpha: 1)
    )

    private let notesCard = QuickAccessCard(
        title: "Add Notes",
        count: nil,
        color: UIColor(red: 0.68, green: 0.30, blue: 0.82, alpha: 1)
    )

    private let gamesCard = QuickAccessCard(
        title: "Games",
        count: nil,
        color: UIColor(red: 0.98, green: 0.82, blue: 0.30, alpha: 1)
    )

    // MARK: - Lifecycle

    override func viewDidLoad() {
            super.viewDidLoad()
            setupGradientBackground()
            setupLayout()
            setupActions()

            progressArc.progress = 0.33
        }
    private func setupGradientBackground() {
        let gradientView = ParentGradientView(frame: view.bounds)
        gradientView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(gradientView)
        view.sendSubviewToBack(gradientView)
        NSLayoutConstraint.activate([
            gradientView.topAnchor.constraint(equalTo: view.topAnchor),
            gradientView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gradientView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
        private func setupLayout() {
            let grid = makeGrid()

            [
                titleLabel, subtitleLabel, progressArc,
                percentLabel, progressTextLabel, quickAccessLabel, grid
            ].forEach {
                $0.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview($0)
            }

            NSLayoutConstraint.activate([
                // Header
                titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
                titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

                subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),
                subtitleLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),

                // Progress
                progressArc.topAnchor.constraint(equalTo: subtitleLabel.bottomAnchor, constant: 20),
                progressArc.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                progressArc.widthAnchor.constraint(equalToConstant: 260),
                progressArc.heightAnchor.constraint(equalToConstant: 140),

                percentLabel.centerXAnchor.constraint(equalTo: progressArc.centerXAnchor),
                percentLabel.topAnchor.constraint(equalTo: progressArc.bottomAnchor, constant: -34),

                progressTextLabel.centerXAnchor.constraint(equalTo: percentLabel.centerXAnchor),
                progressTextLabel.topAnchor.constraint(equalTo: percentLabel.bottomAnchor, constant: 4),

                // Quick Access
                quickAccessLabel.topAnchor.constraint(equalTo: progressTextLabel.bottomAnchor, constant: 20),
                quickAccessLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

                grid.topAnchor.constraint(equalTo: quickAccessLabel.bottomAnchor, constant: 14),
                grid.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                grid.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                
                // Grid bottom constraint to ensure it doesn't overlap the actual tab bar
                grid.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
            ])
        }
    private func makeGrid() -> UIStackView {

        let row1 = UIStackView(arrangedSubviews: [assignmentCard, appointmentCard])
        let row2 = UIStackView(arrangedSubviews: [chatCard, notesCard])
        let row3 = UIStackView(arrangedSubviews: [gamesCard, UIView()])

        [row1, row2, row3].forEach {
            $0.axis = .horizontal
            $0.spacing = 14
            $0.distribution = .fillEqually
        }

        let grid = UIStackView(arrangedSubviews: [row1, row2, row3])
        grid.axis = .vertical
        grid.spacing = 16

        return grid
    }

    // MARK: - Actions

    private func setupActions() {
        assignmentCard.addTarget(self, action: #selector(openAssignments), for: .touchUpInside)
        appointmentCard.addTarget(self, action: #selector(openAppointments), for: .touchUpInside)
        chatCard.addTarget(self, action: #selector(openChat), for: .touchUpInside)
        notesCard.addTarget(self, action: #selector(openNotes), for: .touchUpInside)
        gamesCard.addTarget(self, action: #selector(openGames), for: .touchUpInside)
    }

    @objc private func openAssignments() {
        let assignmentparentVC = AssignmentParentViewController()
        assignmentparentVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(assignmentparentVC, animated: true)
    }

    @objc private func openAppointments() {
        print("Appointments tapped")
    }

    @objc private func openChat() {
        print("Chat tapped")
    }

    @objc private func openNotes() {
        let assignmentparentVC = ParentNotesViewController()
        assignmentparentVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(assignmentparentVC, animated: true)
    }

    @objc private func openGames() {
        let assignmentparentVC = GameListViewController()
        assignmentparentVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(assignmentparentVC, animated: true)
    }
}

