import UIKit

class ParentNotesViewController: UIViewController {

    // Data Source
    var notes: [String] = []
    
    // Programmatic TableView
    private lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.97, alpha: 1.0) // Light Gray
        tv.separatorStyle = .none // Remove lines
        tv.register(NoteCell.self, forCellReuseIdentifier: NoteCell.identifier)
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.97, alpha: 1.0)
        title = "Notes"
        
        setupNavBar()
        setupTableView()
        checkInitialData()
    }
    private func setupNavBar() {
        // Left Button (Back)
        let backBtn = UIBarButtonItem(image: UIImage(systemName: "chevron.backward"), style: .plain, target: self, action: #selector(handleBack))
        navigationItem.leftBarButtonItem = backBtn
        
        // Right Button (Add)
        let addBtn = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(handleAddNote))
        navigationItem.rightBarButtonItem = addBtn
    }
    
    private func setupTableView() {
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        
        // Pin TableView to edges
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // MARK: - Logic
    
    func checkInitialData() {
        // Requirement: Add default note if list is empty
        if notes.isEmpty {
            addNoteWithCurrentDate()
        }
    }
    
    @objc func handleAddNote() {
        addNoteWithCurrentDate()
    }
    
    private func addNoteWithCurrentDate() {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMMM yyyy HH:mm" // e.g., 8 October 2025 09:41
        let dateStr = formatter.string(from: Date())
        
        // Insert at top
        notes.insert(dateStr, at: 0)
        
        // Animate insertion
        tableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
    }
    
    @objc func handleBack() {
        // Handle logic to dismiss or pop
        if let nav = navigationController, nav.viewControllers.count > 1 {
            nav.popViewController(animated: true)
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
}

// MARK: - TableView Delegate & DataSource
extension ParentNotesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NoteCell.identifier, for: indexPath) as? NoteCell else {
            return UITableViewCell()
        }
        cell.configure(date: notes[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80 // Height of card + padding
    }
    
    // Navigation to Detail
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedDateString = notes[indexPath.row]
            
            let detailVC = NoteDetailViewController()
            detailVC.fullDateString = selectedDateString // Pass the full string
            
            navigationController?.pushViewController(detailVC, animated: true)
        }
    
    // Swipe to Delete
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            notes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
