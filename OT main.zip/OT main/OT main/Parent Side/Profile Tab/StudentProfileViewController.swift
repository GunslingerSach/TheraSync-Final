//
//  StudentProfileViewController.swift
//  StudentProfile
//
//  Created by Alishri Poddar on 18/12/25.
//

import UIKit
import PhotosUI

class StudentProfileViewController: UIViewController, PHPickerViewControllerDelegate {

    // MARK: - UI Components
    private let gradientView = ParentGradientView()
    
    private let profileImageView: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "person.circle.fill")
        iv.tintColor = .white
        iv.backgroundColor = .systemGray4
        iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 60
        iv.layer.masksToBounds = true
        iv.isUserInteractionEnabled = true // Allows tap gesture to work
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Ashutosh Anand"
        label.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let menuContainer: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 25
        view.clipsToBounds = true
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let stackView: UIStackView = {
        let sv = UIStackView()
        sv.axis = .vertical
        sv.distribution = .fillEqually
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupProfileTap()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientView.frame = view.bounds
    }
    
    private func setupUI() {
        view.addSubview(gradientView)
        view.addSubview(profileImageView)
        view.addSubview(nameLabel)
        view.addSubview(menuContainer)
        menuContainer.addSubview(stackView)
        
        setupMenuItems()
        setupConstraints()
    }
    
    // MARK: - Photo Selection Logic
    private func setupProfileTap() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(didTapProfilePic))
        profileImageView.addGestureRecognizer(tap)
    }
    
    @objc private func didTapProfilePic() {
        var config = PHPickerConfiguration()
        config.filter = .images
        config.selectionLimit = 1
        
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        present(picker, animated: true)
    }
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        
        guard let provider = results.first?.itemProvider, provider.canLoadObject(ofClass: UIImage.self) else { return }
        
        provider.loadObject(ofClass: UIImage.self) { [weak self] image, error in
            DispatchQueue.main.async {
                if let selectedImage = image as? UIImage {
                    self?.profileImageView.image = selectedImage
                }
            }
        }
    }

    // MARK: - Menu Setup
    private func setupMenuItems() {
        // Clear stack to prevent duplicates
        stackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        let items = ["Update Profile", "Settings", "Terms & Conditions", "About Us", "Log out"]
        
        for (index, title) in items.enumerated() {
            let isLast = (index == items.count - 1)
            let menuRow = createMenuButton(title: title, isDestructive: isLast, showDivider: !isLast)
            stackView.addArrangedSubview(menuRow)
        }
    }
    
    private func createMenuButton(title: String, isDestructive: Bool, showDivider: Bool) -> UIButton {
        let button = UIButton(type: .system)
        button.backgroundColor = .clear
        button.accessibilityIdentifier = title
        button.addTarget(self, action: #selector(menuItemTapped(_:)), for: .touchUpInside)
        
        // Ensure child elements don't block the button's tap area
        let label = UILabel()
        label.text = title
        label.textColor = isDestructive ? .systemRed : .black
        label.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        label.isUserInteractionEnabled = false
        
        button.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: button.leadingAnchor, constant: 20),
            label.centerYAnchor.constraint(equalTo: button.centerYAnchor)
        ])
        
        // Chevron logic
        if !isDestructive {
            let arrow = UIImageView(image: UIImage(systemName: "chevron.right"))
            arrow.tintColor = .systemGray4
            arrow.contentMode = .scaleAspectFit
            arrow.isUserInteractionEnabled = false
            button.addSubview(arrow)
            arrow.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                arrow.trailingAnchor.constraint(equalTo: button.trailingAnchor, constant: -20),
                arrow.centerYAnchor.constraint(equalTo: button.centerYAnchor),
                arrow.widthAnchor.constraint(equalToConstant: 12),
                arrow.heightAnchor.constraint(equalToConstant: 18)
            ])
        }
        
        // Divider line
        if showDivider {
            let line = UIView()
            line.backgroundColor = UIColor.systemGray6
            line.isUserInteractionEnabled = false
            button.addSubview(line)
            line.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                line.leadingAnchor.constraint(equalTo: button.leadingAnchor, constant: 20),
                line.trailingAnchor.constraint(equalTo: button.trailingAnchor, constant: -20),
                line.bottomAnchor.constraint(equalTo: button.bottomAnchor),
                line.heightAnchor.constraint(equalToConstant: 1)
            ])
        }
        
        return button
    }
    
    // MARK: - Navigation Handler
    @objc private func menuItemTapped(_ sender: UIButton) {
        guard let title = sender.accessibilityIdentifier else { return }
        
        // Visual Feedback (Blink)
        UIView.animate(withDuration: 0.1, animations: {
            sender.backgroundColor = UIColor.systemGray6
        }) { _ in
            UIView.animate(withDuration: 0.1) {
                sender.backgroundColor = .clear
            }
        }

        print("\(title) tapped!")
        
        switch title {
        case "Update Profile":
            // Navigate to Update Profile Screen
            break
        case "Settings":
            handleSettings()
            break
        case "Terms & Conditions":
            handleTC()
            break
        case "About Us":
            handleaboutus()
            break
        case "Log out":
            handleLogout()
        default:
            break
        }
    }
    private func handleTC() {
        let updateVC = ParentConditionViewController()
        updateVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(updateVC, animated: true)
    }
    
    private func handleaboutus() {
        let updateVC = ParentAboutUsViewController()
        updateVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(updateVC, animated: true)
    }
    private func handleSettings() {
        let updateVC = SettingsViewController()
        updateVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(updateVC, animated: true)
    }
    private func handleLogout() {
        let alert = UIAlertController(title: "Log Out", message: "Are you sure you want to log out?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        alert.addAction(UIAlertAction(title: "Log Out", style: .destructive, handler: { _ in
            let loginVC = NewLoginViewController()
            let nav = UINavigationController(rootViewController: loginVC)
            nav.setNavigationBarHidden(true, animated: false)
            guard let window = self.view.window else { return }
            window.rootViewController = nav
            UIView.transition(with: window,
                              duration: 0.5,
                              options: .transitionCrossDissolve,
                              animations: nil,
                              completion: nil)
        }))
        self.present(alert, animated: true)
    }
    // MARK: - Layout Constraints
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            profileImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 120),
            profileImageView.heightAnchor.constraint(equalToConstant: 120),
            
            nameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 16),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            menuContainer.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 40),
            menuContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 25),
            menuContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -25),
            menuContainer.heightAnchor.constraint(equalToConstant: 300),
            
            stackView.topAnchor.constraint(equalTo: menuContainer.topAnchor),
            stackView.leadingAnchor.constraint(equalTo: menuContainer.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: menuContainer.trailingAnchor),
            stackView.bottomAnchor.constraint(equalTo: menuContainer.bottomAnchor)
        ])
    }
}
