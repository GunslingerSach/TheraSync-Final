//
//  VolumeSettingsViewController.swift
//  OT main
//
//  Created by Garvit Pareek on 20/12/2025.
//


import UIKit

class VolumeSettingsViewController: UIViewController {
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Maximum Volume Limit"
        label.font = .systemFont(ofSize: 18, weight: .bold)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.text = "Set the highest volume level allowed for game chimes and feedback sounds to prevent sensory overload."
        label.font = .systemFont(ofSize: 14)
        label.textColor = .darkGray
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let volumeSlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 0.0
        slider.maximumValue = 1.0
        slider.minimumTrackTintColor = UIColor(red: 0.24, green: 0.51, blue: 1.0, alpha: 1.0)
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        title = "Audio Volume"
        
        // Load existing limit or default to 0.8
        let savedLimit = UserDefaults.standard.float(forKey: "MaxVolumeLimit")
        volumeSlider.value = savedLimit == 0 ? 0.8 : savedLimit
        
        volumeSlider.addTarget(self, action: #selector(sliderValueChanged(_:)), for: .valueChanged)
    }
    
    private func setupUI() {
        let bg = ParentGradientView()
        bg.frame = view.bounds
        view.addSubview(bg)
        
        let container = UIView()
        container.backgroundColor = .white
        container.layer.cornerRadius = 20
        container.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(container)
        
        container.addSubview(titleLabel)
        container.addSubview(descriptionLabel)
        container.addSubview(volumeSlider)
        
        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            container.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            container.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            container.bottomAnchor.constraint(equalTo: volumeSlider.bottomAnchor, constant: 30),
            
            titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 20),
            
            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            descriptionLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 20),
            descriptionLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -20),
            
            volumeSlider.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 30),
            volumeSlider.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 20),
            volumeSlider.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -20)
        ])
    }
    
    @objc private func sliderValueChanged(_ sender: UISlider) {
        UserDefaults.standard.set(sender.value, forKey: "MaxVolumeLimit")
    }
}