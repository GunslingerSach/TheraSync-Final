//
//  LinkedCaregiversViewController.swift
//  OT main
//
//  Created by Garvit Pareek on 20/12/2025.
//

import UIKit

class LinkedCaregiversViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Properties
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private var caregivers = ["Alishri Poddar (Primary)", "Nanny Maria"]
    
    private let inviteButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Invite New Caregiver", for: .normal)
        btn.backgroundColor = UIColor(red: 0.24, green: 0.51, blue: 1.0, alpha: 1.0)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        title = "Caregivers"
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        // Using the custom gradient background used throughout the Parent app
        let bg = ParentGradientView()
        bg.frame = view.bounds
        view.addSubview(bg)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .clear
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "caregiverCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(tableView)
        view.addSubview(inviteButton)
        
        inviteButton.addTarget(self, action: #selector(showInviteOptions), for: .touchUpInside)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: inviteButton.topAnchor, constant: -20),
            
            inviteButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            inviteButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            inviteButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            inviteButton.heightAnchor.constraint(equalToConstant: 55)
        ])
    }
    
    // MARK: - Invitation Logic
    @objc private func showInviteOptions() {
        let alert = UIAlertController(title: "Invite Caregiver", message: "Choose a method to invite a new caregiver to your child's profile.", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Send Email Invite", style: .default, handler: { _ in
            self.presentEmailInput()
        }))
        
        alert.addAction(UIAlertAction(title: "Share Join Code", style: .default, handler: { _ in
            self.showJoinCode()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
    
    private func presentEmailInput() {
        let alert = UIAlertController(title: "Invite via Email", message: "Enter the email address of the person you'd like to invite.", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "email@example.com" }
        alert.addAction(UIAlertAction(title: "Send", style: .default, handler: { [weak self] _ in
            self?.showToast(message: "Invite sent successfully")
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
    
    private func showJoinCode() {
        let code = "OT-789-XYZ"
        let alert = UIAlertController(title: "Join Code", message: "Share this code with the caregiver: \(code)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Copy Code", style: .default, handler: { _ in
            UIPasteboard.general.string = code
            self.showToast(message: "Code copied to clipboard")
        }))
        alert.addAction(UIAlertAction(title: "OK", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - TableView Data Source
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return caregivers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "caregiverCell", for: indexPath)
        cell.textLabel?.text = caregivers[indexPath.row]
        cell.imageView?.image = UIImage(systemName: "person.circle.fill")
        cell.imageView?.tintColor = .systemGray
        cell.backgroundColor = .white
        cell.accessoryType = caregivers[indexPath.row].contains("(Primary)") ? .none : .disclosureIndicator
        return cell
    }
    
    // MARK: - TableView Delegate (Editing & Removal)
    
    // 1. Edit by Tapping
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if caregivers[indexPath.row].contains("(Primary)") { return }
        showEditAlert(at: indexPath)
    }
    
    private func showEditAlert(at indexPath: IndexPath) {
        let currentName = caregivers[indexPath.row]
        let alert = UIAlertController(title: "Edit Caregiver", message: "Update name or role", preferredStyle: .alert)
        alert.addTextField { $0.text = currentName }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { [weak self] _ in
            if let newName = alert.textFields?.first?.text, !newName.isEmpty {
                self?.caregivers[indexPath.row] = newName
                self?.tableView.reloadRows(at: [indexPath], with: .automatic)
                self?.showToast(message: "Updated successfully")
            }
        }))
        present(alert, animated: true)
    }

    // 2. Remove by Sliding
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if caregivers[indexPath.row].contains("(Primary)") { return nil }
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Remove") { [weak self] (_, _, completion) in
            self?.confirmRemoval(at: indexPath, completionHandler: completion)
        }
        deleteAction.image = UIImage(systemName: "trash.fill")
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
    private func confirmRemoval(at indexPath: IndexPath, completionHandler: @escaping (Bool) -> Void) {
        let name = caregivers[indexPath.row]
        let alert = UIAlertController(title: "Remove Caregiver?", message: "Confirm removal of \(name)", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in completionHandler(false) }))
        alert.addAction(UIAlertAction(title: "Remove", style: .destructive, handler: { [weak self] _ in
            self?.caregivers.remove(at: indexPath.row)
            self?.tableView.deleteRows(at: [indexPath], with: .fade)
            self?.showToast(message: "Caregiver removed")
            completionHandler(true)
        }))
        present(alert, animated: true)
    }

    // MARK: - Toast Notification
    private func showToast(message: String) {
        let toastLabel = UILabel()
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastLabel.textColor = .white
        toastLabel.textAlignment = .center
        toastLabel.font = .systemFont(ofSize: 14, weight: .medium)
        toastLabel.text = message
        toastLabel.layer.cornerRadius = 20
        toastLabel.clipsToBounds = true
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(toastLabel)
        
        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -100),
            toastLabel.widthAnchor.constraint(equalToConstant: 250),
            toastLabel.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        UIView.animate(withDuration: 0.5, delay: 2.0, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in toastLabel.removeFromSuperview() })
    }
}
