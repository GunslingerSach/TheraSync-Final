//
//  ThemesSettingsViewController.swift
//  OT main
//
//  Created by Garvit Pareek on 20/12/2025.
//
import UIKit

class ThemesSettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    
    private let options = [
        ("High Contrast", "Increases visibility of buttons and text"),
        ("Reduced Motion", "Simplifies animations for sensitive eyes"),
        ("Dark Mode", "Reduces screen brightness and glare")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        title = "Themes & Motion"
    }
    
    private func setupUI() {
        let bg = ParentGradientView()
        bg.frame = view.bounds
        view.addSubview(bg)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .clear
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "themeCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let isDarkMode = UserDefaults.standard.bool(forKey: "Dark Mode")
        // Ensure the current window matches the saved setting
        view.window?.overrideUserInterfaceStyle = isDarkMode ? .dark : .light
    }
    // MARK: - TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "themeCell")
        let option = options[indexPath.row]
        
        cell.textLabel?.text = option.0
        cell.detailTextLabel?.text = option.1
        
        // Check if Dark Mode is currently active
        let isDarkMode = traitCollection.userInterfaceStyle == .dark
        
        if isDarkMode {
            // --- DARK MODE STYLE ---
            // Very light gray card background
            cell.backgroundColor = UIColor(white: 0.25, alpha: 1.0)
            // Pure white text
            cell.textLabel?.textColor = .white
            // Light gray for the sub-description
            cell.detailTextLabel?.textColor = UIColor(white: 0.8, alpha: 1.0)
        } else {
            // --- LIGHT MODE STYLE ---
            // Solid white card
            cell.backgroundColor = .white
            // Solid black text
            cell.textLabel?.textColor = .black
            // Standard gray for description
            cell.detailTextLabel?.textColor = .gray
        }
        
        let switchView = UISwitch()
        switchView.isOn = UserDefaults.standard.bool(forKey: option.0)
        switchView.tag = indexPath.row
        switchView.addTarget(self, action: #selector(themeChanged(_:)), for: .valueChanged)
        
        cell.accessoryView = switchView
        cell.selectionStyle = .none
        
        return cell
    }
    
    @objc private func themeChanged(_ sender: UISwitch) {
        let optionName = options[sender.tag].0
        UserDefaults.standard.set(sender.isOn, forKey: optionName)
        
        if optionName == "Dark Mode" {
            view.window?.overrideUserInterfaceStyle = sender.isOn ? .dark : .light
            // This forces the table to re-run cellForRowAt and pick up the new colors
            tableView.reloadData()
        }
        
        NotificationCenter.default.post(name: NSNotification.Name("AppThemeChanged"), object: nil)
        UISelectionFeedbackGenerator().selectionChanged()
    }
}
