// ForgotPasswordViewController.swift
import UIKit

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField?
    @IBOutlet weak var sendOTPButton: UIButton?

    // MARK: - UI

    private let progEmailLabel: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.text = "Email"
        lbl.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        lbl.textColor = .label
        return lbl
    }()

    private let progEmailField: UITextField = {
        let tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.backgroundColor = .white
        tf.layer.cornerRadius = 28
        tf.layer.masksToBounds = false

        tf.layer.shadowColor = UIColor.black.cgColor
        tf.layer.shadowOpacity = 0.06
        tf.layer.shadowRadius = 8
        tf.layer.shadowOffset = CGSize(width: 0, height: 3)

        let pad = UIView(frame: CGRect(x: 0, y: 0, width: 18, height: 1))
        tf.leftView = pad
        tf.leftViewMode = .always

        tf.font = UIFont.systemFont(ofSize: 16)
        tf.keyboardType = .emailAddress
        tf.autocapitalizationType = .none

        tf.attributedPlaceholder = NSAttributedString(
            string: "something@email.com",
            attributes: [
                .foregroundColor: UIColor.systemGray3,
                .font: UIFont.systemFont(ofSize: 15)
            ]
        )
        return tf
    }()

    private let progSendOTPButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("Send OTP", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        btn.backgroundColor = UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1)
        btn.layer.cornerRadius = 22
        return btn
    }()

    private let gradientHeader = UIView()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor(white: 0.96, alpha: 1)

        configureNavigationAppearance()
        configureNavigationItems()

        emailTextField?.isHidden = true
        sendOTPButton?.isHidden = true
        hideAnyXIBEmailLabel()

        setupGradient()
        setupHierarchy()
        setupConstraints()

        progSendOTPButton.addTarget(self, action: #selector(handleSendOTP), for: .touchUpInside)
        progEmailField.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavigationAppearance()
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNeedsStatusBarAppearanceUpdate()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientHeader.layer.sublayers?.first?.frame = gradientHeader.bounds
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    // MARK: - NAVBAR

    private func configureNavigationAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear

        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 18, weight: .semibold)
        ]

        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance

        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.backgroundColor = .clear
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.barStyle = .black

        navigationController?.view.backgroundColor = .clear
    }

    // ⭐ FIXED CLEAN BACK BUTTON (NO LEAF PATTERN)

    private func configureNavigationItems() {
        // title
        let titleLbl = UILabel()
        titleLbl.text = "Forgot Password"
        titleLbl.textColor = .white
        titleLbl.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        navigationItem.titleView = titleLbl

        // Create an invisible tappable container so we keep a good hit area
        let size: CGFloat = 44
        let container = UIView(frame: CGRect(x: 0, y: 0, width: size, height: size))
        container.backgroundColor = .clear          // <- NO white background
        container.isOpaque = true
        container.layer.contents = nil
        container.layer.shadowOpacity = 0

        // Chevron (templated) image view
        let cfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .regular)
        let img = UIImage(systemName: "chevron.left", withConfiguration: cfg)?.withRenderingMode(.alwaysTemplate)
        let iv = UIImageView(image: img)
        iv.translatesAutoresizingMaskIntoConstraints = false

        // Tint the chevron — currently dark; set to .white if you want white chevron
        iv.tintColor = UIColor(white: 0.12, alpha: 1)

        // Make sure the image has a fixed size so it doesn't scale weirdly
        container.addSubview(iv)
        NSLayoutConstraint.activate([
            iv.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            iv.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iv.widthAnchor.constraint(equalToConstant: 18),
            iv.heightAnchor.constraint(equalToConstant: 24)
        ])

        // Add tap recognizer (keeping it simple, no button)
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleBack))
        container.addGestureRecognizer(tap)

        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: container)
        navigationController?.interactivePopGestureRecognizer?.delegate = nil
    }



    // MARK: - GRADIENT

    private func setupGradient() {
        gradientHeader.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(gradientHeader)

        NSLayoutConstraint.activate([
            gradientHeader.topAnchor.constraint(equalTo: view.topAnchor),
            gradientHeader.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientHeader.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gradientHeader.heightAnchor.constraint(equalToConstant: 310)
        ])

        let g = CAGradientLayer()
        g.colors = [
            UIColor(red: 0.29, green: 0.61, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.63, green: 0.80, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.92, green: 0.95, blue: 0.98, alpha: 1).cgColor
        ]
        g.locations = [0, 0.45, 1]
        g.startPoint = CGPoint(x: 0.5, y: 0)
        g.endPoint = CGPoint(x: 0.5, y: 1)
        gradientHeader.layer.insertSublayer(g, at: 0)
    }

    // MARK: - Layout

    private func setupHierarchy() {
        view.addSubview(progEmailLabel)
        view.addSubview(progEmailField)
        view.addSubview(progSendOTPButton)
    }

    private func setupConstraints() {
        let safe = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            progEmailLabel.topAnchor.constraint(equalTo: safe.topAnchor, constant: 30),
            progEmailLabel.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 30),

            progEmailField.topAnchor.constraint(equalTo: progEmailLabel.bottomAnchor, constant: 12),
            progEmailField.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 30),
            progEmailField.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -30),
            progEmailField.heightAnchor.constraint(equalToConstant: 56),

            progSendOTPButton.topAnchor.constraint(equalTo: progEmailField.bottomAnchor, constant: 20),
            progSendOTPButton.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 30),
            progSendOTPButton.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -30),
            progSendOTPButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    // MARK: - Helpers

    private func hideAnyXIBEmailLabel() {
        func hide(in view: UIView) {
            for v in view.subviews {
                if let lbl = v as? UILabel, lbl.text == "Email" {
                    lbl.isHidden = true
                }
                hide(in: v)
            }
        }
        hide(in: self.view)
    }

    // MARK: - Actions

    @objc private func handleBack() {
        navigationController?.popViewController(animated: true)
    }

    @objc private func handleSendOTP() {
        view.endEditing(true)

        guard let email = progEmailField.text, !email.isEmpty else {
            showAlert("Enter Email", "Please enter your registered email.")
            return
        }

        let reg = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        if NSPredicate(format: "SELF MATCHES %@", reg).evaluate(with: email) == false {
            showAlert("Invalid Email", "Please enter a valid email.")
            return
        }

        let vc = EnterOTPViewController(nibName: "EnterOTPViewController", bundle: nil)
        navigationController?.pushViewController(vc, animated: true)
    }

    private func showAlert(_ title: String, _ msg: String) {
        let alert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension ForgotPasswordViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        handleSendOTP()
        return true
    }
}
