// NewPasswordViewController.swift
// TheraSync-Final
//
// Created by user@54 on 11/11/25.
//

import UIKit

class NewPasswordViewController: UIViewController {

    @IBOutlet weak var newPasswordTextField: UITextField?
    @IBOutlet weak var confirmPasswordTextField: UITextField?
    @IBOutlet weak var submitButton: UIButton?

    var email: String?

    // Visual header
    private let gradientHeader = UIView()
    private let gradientHeight: CGFloat = 260

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor(white: 0.96, alpha: 1)

        configureNavBarAppearance()
        configureNavigationItems()
        setupGradientHeader()

        // Style existing XIB label/textfields/buttons without creating new labels
        styleFieldsAndButton()
        hookTextFieldTargets()
        layoutFieldsIfNeeded()

        newPasswordTextField?.becomeFirstResponder()
        setSubmitEnabled(false)

        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavBarAppearance()
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNeedsStatusBarAppearanceUpdate()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientHeader.layer.sublayers?.first?.frame = gradientHeader.bounds
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - Nav & Gradient

    private func configureNavBarAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 17, weight: .semibold)
        ]

        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance

        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.backgroundColor = .clear
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.barStyle = .black
        navigationController?.view.backgroundColor = .clear
    }

    // <-- Replaced function: integrated the chevron container you gave -->
    private func configureNavigationItems() {
        // title
        let titleLbl = UILabel()
        titleLbl.text = "Forgot Password"
        titleLbl.textColor = .white
        titleLbl.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        navigationItem.titleView = titleLbl

        // Create an invisible tappable container so we keep a good hit area
        let size: CGFloat = 44
        let container = UIView(frame: CGRect(x: 0, y: 0, width: size, height: size))
        container.backgroundColor = .clear          // <- NO white background
        container.isOpaque = true
        container.layer.contents = nil
        container.layer.shadowOpacity = 0

        // Chevron (templated) image view
        let cfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .regular)
        let img = UIImage(systemName: "chevron.left", withConfiguration: cfg)?.withRenderingMode(.alwaysTemplate)
        let iv = UIImageView(image: img)
        iv.translatesAutoresizingMaskIntoConstraints = false

        // Tint the chevron — currently dark; set to .white if you want white chevron
        iv.tintColor = UIColor(white: 0.12, alpha: 1)

        // Make sure the image has a fixed size so it doesn't scale weirdly
        container.addSubview(iv)
        NSLayoutConstraint.activate([
            iv.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            iv.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iv.widthAnchor.constraint(equalToConstant: 18),
            iv.heightAnchor.constraint(equalToConstant: 24)
        ])

        // Add tap recognizer (keeping it simple, no button)
        let tap = UITapGestureRecognizer(target: self, action: #selector(backTapped))
        container.addGestureRecognizer(tap)

        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: container)
        navigationController?.interactivePopGestureRecognizer?.delegate = nil
    }

    private func setupGradientHeader() {
        gradientHeader.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(gradientHeader, at: 0)

        NSLayoutConstraint.activate([
            gradientHeader.topAnchor.constraint(equalTo: view.topAnchor),
            gradientHeader.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientHeader.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gradientHeader.heightAnchor.constraint(equalToConstant: gradientHeight)
        ])

        let g = CAGradientLayer()
        g.colors = [
            UIColor(red: 0.29, green: 0.61, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.63, green: 0.80, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.92, green: 0.95, blue: 0.98, alpha: 1).cgColor
        ]
        g.locations = [0, 0.45, 1]
        g.startPoint = CGPoint(x: 0.5, y: 0)
        g.endPoint = CGPoint(x: 0.5, y: 1)
        gradientHeader.layer.insertSublayer(g, at: 0)
    }

    // MARK: - Styling & Layout

    private func styleFieldsAndButton() {
        let cornerRadius: CGFloat = 26
        let fieldHeight: CGFloat = 52
        let placeholderColor = UIColor(white: 0.78, alpha: 1)

        let fields: [UITextField] = [newPasswordTextField, confirmPasswordTextField].compactMap { $0 }
        for tf in fields {
            tf.backgroundColor = .white
            tf.layer.cornerRadius = cornerRadius
            tf.layer.masksToBounds = false
            tf.layer.shadowColor = UIColor.black.cgColor
            tf.layer.shadowOpacity = 0.08
            tf.layer.shadowRadius = 8
            tf.layer.shadowOffset = CGSize(width: 0, height: 4)

            tf.font = UIFont.systemFont(ofSize: 16)
            tf.textColor = .darkText
            tf.tintColor = UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1)
            tf.autocorrectionType = .no
            tf.isSecureTextEntry = true
            tf.delegate = self

            tf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 18, height: fieldHeight))
            tf.leftViewMode = .always

            if tf == newPasswordTextField {
                tf.attributedPlaceholder = NSAttributedString(string: "new password", attributes: [.foregroundColor: placeholderColor, .font: UIFont.systemFont(ofSize: 15)])
            } else {
                tf.attributedPlaceholder = NSAttributedString(string: "confirm password", attributes: [.foregroundColor: placeholderColor, .font: UIFont.systemFont(ofSize: 15)])
            }

            tf.translatesAutoresizingMaskIntoConstraints = false
            if !hasConstraintAffecting(tf, attribute: .height) {
                tf.heightAnchor.constraint(equalToConstant: fieldHeight).isActive = true
            }
        }

        if let btn = submitButton {
            btn.layer.cornerRadius = 22
            btn.layer.masksToBounds = true
            btn.setTitle("Submit", for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .regular)
            btn.setTitleColor(.white, for: .normal)
            btn.backgroundColor = UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1)
            btn.alpha = 1.0
            btn.translatesAutoresizingMaskIntoConstraints = false
            if !hasConstraintAffecting(btn, attribute: .height) {
                btn.heightAnchor.constraint(equalToConstant: 52).isActive = true
            }
        }
    }

    // Only add mild positioning constraints if XIB didn't supply them
    private func layoutFieldsIfNeeded() {
        guard let newTF = newPasswordTextField, let confirmTF = confirmPasswordTextField else { return }

        if !hasConstraintAffecting(newTF, attribute: .top) {
            newTF.translatesAutoresizingMaskIntoConstraints = false
            newTF.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100).isActive = true
            newTF.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24).isActive = true
            newTF.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24).isActive = true
        }

        if !hasConstraintAffecting(confirmTF, attribute: .top) {
            confirmTF.translatesAutoresizingMaskIntoConstraints = false
            confirmTF.topAnchor.constraint(equalTo: newTF.bottomAnchor, constant: 36).isActive = true
            confirmTF.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24).isActive = true
            confirmTF.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24).isActive = true
        }

        if let btn = submitButton, !hasConstraintAffecting(btn, attribute: .top) {
            btn.translatesAutoresizingMaskIntoConstraints = false
            btn.topAnchor.constraint(equalTo: confirmTF.bottomAnchor, constant: 34).isActive = true
            btn.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24).isActive = true
            btn.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24).isActive = true
        }

        // ensure nav title sits above gradient
        if let titleView = navigationItem.titleView {
            view.bringSubviewToFront(titleView)
        }
    }

    private func hasConstraintAffecting(_ view: UIView, attribute: NSLayoutConstraint.Attribute) -> Bool {
        for c in view.constraints {
            if c.firstAttribute == attribute || c.secondAttribute == attribute { return true }
        }
        var v = view
        while let s = v.superview {
            for c in s.constraints {
                if (c.firstItem as? UIView) == view || (c.secondItem as? UIView) == view {
                    if c.firstAttribute == attribute || c.secondAttribute == attribute { return true }
                }
            }
            v = s
        }
        return false
    }

    // MARK: - Text handling

    private func hookTextFieldTargets() {
        newPasswordTextField?.addTarget(self, action: #selector(textChanged(_:)), for: .editingChanged)
        confirmPasswordTextField?.addTarget(self, action: #selector(textChanged(_:)), for: .editingChanged)
    }

    @objc private func textChanged(_ tf: UITextField) {
        let a = newPasswordTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let b = confirmPasswordTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let enabled = !a.isEmpty && !b.isEmpty && a == b
        setSubmitEnabled(enabled)
    }

    private func setSubmitEnabled(_ enabled: Bool) {
        guard let btn = submitButton else { return }
        btn.isEnabled = enabled
        UIView.animate(withDuration: 0.12) {
            btn.alpha = enabled ? 1.0 : 0.55
            btn.backgroundColor = enabled ? UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1) : UIColor(white: 0.88, alpha: 1)
            btn.setTitleColor(enabled ? .white : UIColor(white: 0.6, alpha: 1), for: .normal)
        }
    }

    // MARK: - Actions

    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc private func backTapped() {
        if let nav = navigationController {
            if nav.viewControllers.first == self {
                nav.dismiss(animated: true, completion: nil)
            } else {
                nav.popViewController(animated: true)
            }
        } else {
            dismiss(animated: true, completion: nil)
        }
    }

    @IBAction func submitTapped(_ sender: UIButton) {
        view.endEditing(true)

        guard let p = newPasswordTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !p.isEmpty,
              let cp = confirmPasswordTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !cp.isEmpty else {
            showAlert(title: "Missing", message: "Please enter and confirm your new password.")
            return
        }

        guard p == cp else {
            showAlert(title: "Mismatch", message: "Passwords do not match.")
            return
        }

        showAlert(title: "Success", message: "Password changed. Please login.") { [weak self] in
            if let nav = self?.navigationController {
                nav.popToRootViewController(animated: true)
            } else {
                self?.dismiss(animated: true, completion: nil)
            }
        }
    }

    private func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let a = UIAlertController(title: title, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completion?() })
        present(a, animated: true)
    }
}

extension NewPasswordViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == newPasswordTextField {
            confirmPasswordTextField?.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
}
