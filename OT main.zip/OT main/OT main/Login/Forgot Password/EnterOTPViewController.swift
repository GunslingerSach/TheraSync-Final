// EnterOTPViewController.swift
// TheraSync-Final
//
// Created by user@54 on 11/11/25.
//

import UIKit

class EnterOTPViewController: UIViewController {

    // Keep IBOutlets exactly as named in your XIB
    @IBOutlet weak var otpField1: UITextField?
    @IBOutlet weak var otpField2: UITextField?
    @IBOutlet weak var otpField3: UITextField?
    @IBOutlet weak var otpField4: UITextField?
    @IBOutlet weak var doneButton: UIButton?    // we will re-parent this below the boxes

    var email: String?

    // Programmatic UI
    private let gradientHeader = UIView()
    private let bigTitleLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Enter OTP"
        l.font = UIFont.systemFont(ofSize: 30, weight: .semibold) // slightly larger
        l.textAlignment = .center
        l.textColor = .black // requested black title
        l.numberOfLines = 1
        l.setContentCompressionResistancePriority(.required, for: .vertical)
        return l
    }()

    private var otpFields: [UITextField] {
        return [otpField1, otpField2, otpField3, otpField4].compactMap { $0 }
    }

    // layout tuning
    private var titleTopConstraint: NSLayoutConstraint?
    private var containerTopOffset: CGFloat = 28 // spacing between title and boxes
    private let gradientHeight: CGFloat = 260

    // tag for container we create programmatically
    private let otpContainerTag = 987654

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.96, alpha: 1)

        configureNavBarAppearance()
        configureNavigationItems()

        setupGradientHeader()

        // Add title label (placed safely below nav)
        view.addSubview(bigTitleLabel)
        titleTopConstraint = bigTitleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 72) // push below nav
        titleTopConstraint?.isActive = true
        NSLayoutConstraint.activate([
            bigTitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        view.bringSubviewToFront(bigTitleLabel)

        // Style fields & button and layout boxes/button programmatically
        styleFieldsAndButton()

        // focus first field
        otpField1?.becomeFirstResponder()

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavBarAppearance()
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNeedsStatusBarAppearanceUpdate()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientHeader.layer.sublayers?.first?.frame = gradientHeader.bounds
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - Nav & Gradient

    private func configureNavBarAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 17, weight: .semibold)
        ]

        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance

        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.backgroundColor = .clear
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.barStyle = .black
        navigationController?.view.backgroundColor = .clear
    }

    // <-- Integrated clean chevron container (same working version you used) -->
    private func configureNavigationItems() {
        // title centered in nav with white text (matches design)
        let titleLabel = UILabel()
        titleLabel.text = "Forgot Password"
        titleLabel.font = .systemFont(ofSize: 17, weight: .semibold)
        titleLabel.textColor = .white
        navigationItem.titleView = titleLabel

        // Create an invisible tappable container so we keep a good hit area
        let size: CGFloat = 44
        let container = UIView(frame: CGRect(x: 0, y: 0, width: size, height: size))
        container.backgroundColor = .clear          // <- NO white background
        container.isOpaque = true
        container.layer.contents = nil
        container.layer.shadowOpacity = 0

        // Chevron (templated) image view
        let cfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .regular)
        let img = UIImage(systemName: "chevron.left", withConfiguration: cfg)?.withRenderingMode(.alwaysTemplate)
        let iv = UIImageView(image: img)
        iv.translatesAutoresizingMaskIntoConstraints = false

        // Tint the chevron — currently dark; set to .white if you want white chevron
        iv.tintColor = UIColor(white: 0.12, alpha: 1)

        // Make sure the image has a fixed size so it doesn't scale weirdly
        container.addSubview(iv)
        NSLayoutConstraint.activate([
            iv.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            iv.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iv.widthAnchor.constraint(equalToConstant: 18),
            iv.heightAnchor.constraint(equalToConstant: 24)
        ])

        // Add tap recognizer (keeping it simple, no button)
        let tap = UITapGestureRecognizer(target: self, action: #selector(backTapped))
        container.addGestureRecognizer(tap)

        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: container)
        navigationController?.interactivePopGestureRecognizer?.delegate = nil
    }

    private func setupGradientHeader() {
        gradientHeader.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(gradientHeader, at: 0)
        NSLayoutConstraint.activate([
            gradientHeader.topAnchor.constraint(equalTo: view.topAnchor),
            gradientHeader.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gradientHeader.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            gradientHeader.heightAnchor.constraint(equalToConstant: gradientHeight)
        ])

        let g = CAGradientLayer()
        g.colors = [
            UIColor(red: 0.29, green: 0.61, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.63, green: 0.80, blue: 1.00, alpha: 1).cgColor,
            UIColor(red: 0.92, green: 0.95, blue: 0.98, alpha: 1).cgColor
        ]
        g.locations = [0, 0.45, 1]
        g.startPoint = CGPoint(x: 0.5, y: 0)
        g.endPoint = CGPoint(x: 0.5, y: 1)
        gradientHeader.layer.insertSublayer(g, at: 0)
    }

    // MARK: - Styling & Layout

    private func styleFieldsAndButton() {
        // requested sizes & radii
        let boxSize: CGFloat = 64
        let cornerRadius: CGFloat = 15

        // ensure each OTP field has visual style and delegate
        for tf in otpFields {
            tf.backgroundColor = .white
            tf.layer.cornerRadius = cornerRadius
            tf.layer.masksToBounds = false
            tf.layer.borderWidth = 1
            tf.layer.borderColor = UIColor(white: 0.85, alpha: 1).cgColor
            tf.layer.shadowColor = UIColor.black.cgColor
            tf.layer.shadowOpacity = 0.06
            tf.layer.shadowRadius = 6
            tf.layer.shadowOffset = CGSize(width: 0, height: 3)
            tf.font = UIFont.monospacedDigitSystemFont(ofSize: 22, weight: .medium)
            tf.textAlignment = .center
            tf.keyboardType = .numberPad
            tf.tintColor = UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1)
            tf.autocorrectionType = .no
            tf.delegate = self
            tf.text = ""
            tf.addTarget(self, action: #selector(textFieldEditingChanged(_:)), for: .editingChanged)
            tf.translatesAutoresizingMaskIntoConstraints = false
        }

        // Style done button (we will re-add below OTP boxes to ensure correct placement)
        if let btn = doneButton {
            btn.layer.cornerRadius = 22
            btn.layer.masksToBounds = true
            btn.setTitle("Done", for: .normal)
            btn.setTitleColor(.white, for: .normal)
            btn.backgroundColor = UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1)
            btn.isEnabled = false
            btn.alpha = 0.55
            btn.removeFromSuperview() // remove from XIB parent to avoid conflicts
        }

        // Layout OTP boxes and re-add Done button below them (programmatic, non-invasive)
        layoutOTPBoxesProgrammatically(boxSize: boxSize)
    }

    private func layoutOTPBoxesProgrammatically(boxSize: CGFloat) {
        // remove previous container if exists (safe-guard for hot reloads)
        if let old = view.viewWithTag(otpContainerTag) {
            old.removeFromSuperview()
        }

        let container = UIView()
        container.tag = otpContainerTag
        container.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(container)

        // container placed below big title
        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: bigTitleLabel.bottomAnchor, constant: containerTopOffset),
            container.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            container.heightAnchor.constraint(equalToConstant: boxSize)
        ])

        // add otp fields inside the container
        for f in otpFields {
            container.addSubview(f)
            f.translatesAutoresizingMaskIntoConstraints = false
        }

        // spacing and constraints
        let spacing: CGFloat = 16
        for (i, f) in otpFields.enumerated() {
            NSLayoutConstraint.activate([
                f.widthAnchor.constraint(equalToConstant: boxSize),
                f.heightAnchor.constraint(equalToConstant: boxSize),
                f.centerYAnchor.constraint(equalTo: container.centerYAnchor)
            ])
            if i == 0 {
                f.leadingAnchor.constraint(equalTo: container.leadingAnchor).isActive = true
            } else {
                f.leadingAnchor.constraint(equalTo: otpFields[i-1].trailingAnchor, constant: spacing).isActive = true
            }
            if i == otpFields.count - 1 {
                f.trailingAnchor.constraint(equalTo: container.trailingAnchor).isActive = true
            }
        }

        // re-add doneButton (programmatic) below the container to guarantee placement
        if let btn = doneButton {
            btn.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(btn)
            NSLayoutConstraint.activate([
                btn.topAnchor.constraint(equalTo: container.bottomAnchor, constant: 28),
                btn.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 30),
                btn.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -30),
                btn.heightAnchor.constraint(equalToConstant: 52)
            ])
        }

        // ensure big title is on top
        view.bringSubviewToFront(bigTitleLabel)
    }

    // MARK: - Keyboard handling

    @objc private func keyboardWillShow(_ n: Notification) {
        guard let kbFrame = n.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        let kbHeight = kbFrame.height
        let margin: CGFloat = 12
        if let btn = doneButton {
            view.layoutIfNeeded()
            let btnFrameInWindow = btn.convert(btn.bounds, to: nil)
            let screenHeight = UIScreen.main.bounds.height
            let overlap = (btnFrameInWindow.maxY + margin) - (screenHeight - kbHeight)
            if overlap > 0 {
                UIView.animate(withDuration: 0.28) {
                    self.view.frame.origin.y = self.view.frame.origin.y - (overlap + 10)
                }
            }
        }
    }

    @objc private func keyboardWillHide(_ n: Notification) {
        // reset to default (safe — simplest)
        UIView.animate(withDuration: 0.28) {
            self.view.frame.origin.y = 0
        }
    }

    // MARK: - Text changes & paste

    @objc private func textFieldEditingChanged(_ textField: UITextField) {
        // handle paste
        if let txt = textField.text, txt.count > 1 {
            handlePaste(txt)
            return
        }
        // move next when single char entered
        if let idx = otpFields.firstIndex(of: textField), let txt = textField.text, txt.count == 1 {
            let next = idx + 1
            if next < otpFields.count {
                otpFields[next].becomeFirstResponder()
            } else {
                textField.resignFirstResponder()
            }
        }
        updateDoneButtonState()
    }

    private func handlePaste(_ pasted: String) {
        let digits = pasted.filter { $0.isNumber }
        guard digits.count > 0 else { return }
        let chars = Array(digits)
        for i in 0..<otpFields.count {
            otpFields[i].text = (i < chars.count) ? String(chars[i]) : ""
        }
        if chars.count < otpFields.count {
            otpFields[chars.count].becomeFirstResponder()
        } else {
            view.endEditing(true)
        }
        updateDoneButtonState()
    }

    private func currentOTP() -> String {
        return otpFields.map { $0.text ?? "" }.joined()
    }

    private func updateDoneButtonState() {
        let otp = currentOTP()
        let ready = otp.count == otpFields.count
        doneButton?.isEnabled = ready
        UIView.animate(withDuration: 0.12) {
            self.doneButton?.alpha = ready ? 1.0 : 0.55
            self.doneButton?.backgroundColor = ready ? UIColor(red: 0.18, green: 0.56, blue: 0.99, alpha: 1) : UIColor(white: 0.88, alpha: 1)
            self.doneButton?.setTitleColor(ready ? .white : UIColor(white: 0.5, alpha: 1), for: .normal)
        }
    }

    // MARK: - Actions

    @IBAction func doneTapped(_ sender: UIButton) {
        view.endEditing(true)
        let otp = currentOTP()
        guard otp.count == otpFields.count else {
            if let firstEmpty = otpFields.first(where: { ($0.text ?? "").isEmpty }) {
                shake(view: firstEmpty)
            }
            return
        }
        let newPasswordVC = NewPasswordViewController(nibName: "NewPasswordViewController", bundle: nil)
        if let nav = navigationController {
            nav.pushViewController(newPasswordVC, animated: true)
        } else {
            newPasswordVC.modalPresentationStyle = .fullScreen
            present(newPasswordVC, animated: true, completion: nil)
        }
    }

    @objc private func backTapped() {
        if let nav = navigationController {
            if nav.viewControllers.first == self {
                nav.dismiss(animated: true, completion: nil)
            } else {
                nav.popViewController(animated: true)
            }
        } else {
            dismiss(animated: true, completion: nil)
        }
    }

    private func shake(view: UIView) {
        let a = CAKeyframeAnimation(keyPath: "transform.translation.x")
        a.timingFunction = CAMediaTimingFunction(name: .linear)
        a.duration = 0.45
        a.values = [-8, 8, -6, 6, -3, 3, 0]
        view.layer.add(a, forKey: "shake")
    }
}

// MARK: - UITextFieldDelegate
extension EnterOTPViewController: UITextFieldDelegate {

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        for tf in otpFields {
            if (tf.text ?? "").isEmpty {
                if let tappedIndex = otpFields.firstIndex(of: textField),
                   let firstEmptyIndex = otpFields.firstIndex(of: tf),
                   tappedIndex > firstEmptyIndex {
                    otpFields[firstEmptyIndex].becomeFirstResponder()
                    return false
                }
                break
            }
        }
        return true
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // paste: allow -> will be handled in editingChanged
        if string.count > 1 { return true }
        // backspace: go back to previous and clear
        if string.isEmpty {
            textField.text = ""
            if let idx = otpFields.firstIndex(of: textField), idx > 0 {
                otpFields[idx - 1].becomeFirstResponder()
            }
            updateDoneButtonState()
            return false
        }
        // allow only digits
        guard CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: string)) else { return false }
        // set the digit manually and move forward
        textField.text = string
        if let idx = otpFields.firstIndex(of: textField) {
            let next = idx + 1
            if next < otpFields.count {
                otpFields[next].becomeFirstResponder()
            } else {
                textField.resignFirstResponder()
            }
        }
        updateDoneButtonState()
        return false
    }
}
